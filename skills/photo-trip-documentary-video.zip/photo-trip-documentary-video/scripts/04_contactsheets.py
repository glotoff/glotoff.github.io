"""Step 4a: contact sheets per stop (sharp photos, time-ordered, capped) + clip frames -> build/sheets"""
import json, subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__import__("os").environ.get("TRIP_ROOT", "."))
SRC = ROOT / __import__("os").environ.get("MEDIA_DIR", "photos-and-videos")
BUILD = Path(__import__("os").environ.get("TRIP_BUILD") or ROOT / "build")
SHEETS = BUILD / "sheets"
SHEETS.mkdir(exist_ok=True)
FR = BUILD / "clipframes"
FR.mkdir(exist_ok=True)
FFMPEG = "ffmpeg"

COLS, ROWS, TW, TH = 6, 5, 300, 225
PER = COLS * ROWS
CAP = 90  # max photos per stop shown
try:
    font = ImageFont.truetype(__import__("os").environ.get("FONT_BOLD", r"C:\Windows\Fontsrialbd.ttf"), 15)
except Exception:
    font = ImageFont.load_default()

stops = json.loads((BUILD / "stops.json").read_text(encoding="utf-8"))
manifest = {}

def clip_frame(name):
    out = FR / (Path(name).stem + ".jpg")
    if not out.exists():
        subprocess.run([FFMPEG, "-y", "-loglevel", "error", "-ss", "1", "-i", str(SRC / name),
                        "-frames:v", "1", "-vf", "scale=900:-2", str(out)], check=False)
    return out if out.exists() else None

for st in stops:
    photos = [f for f in st["files"] if f["kind"] == "photo" and not f["blurry"]]
    clips = [f for f in st["files"] if f["kind"] == "video"]
    if len(photos) > CAP:
        # keep top-quality CAP photos, preserve time order
        top = sorted(photos, key=lambda f: -(f["q"] or 0))[:CAP]
        photos = sorted(top, key=lambda f: f["t"])
    entries = [(f, "P") for f in photos] + [(f, "V") for f in clips]
    if not entries:
        continue
    for part in range(0, len(entries), PER):
        chunk = entries[part:part + PER]
        sheet = Image.new("RGB", (COLS * TW, ROWS * TH), (18, 18, 18))
        d = ImageDraw.Draw(sheet)
        for k, (f, kind) in enumerate(chunk):
            src = (FR / (Path(f["file"]).stem + ".jpg")) if kind == "V" else (BUILD / "thumbs" / (Path(f["file"]).stem + ".jpg"))
            if kind == "V":
                src = clip_frame(f["file"])
            if not src or not Path(src).exists():
                continue
            im = Image.open(src).convert("RGB")
            im.thumbnail((TW - 4, TH - 4))
            x, y = (k % COLS) * TW, (k // COLS) * TH
            sheet.paste(im, (x + (TW - im.width) // 2, y + (TH - im.height) // 2))
            label = f"{st['id']}.{part + k + 1}" + (" VID" if kind == "V" else "")
            d.rectangle([x, y, x + 78 + (34 if kind == "V" else 0), y + 20], fill=(0, 0, 0))
            d.text((x + 4, y + 2), label, fill=(255, 220, 90), font=font)
            manifest[label] = dict(file=f["file"], kind=kind, t=f["t"], stop=st["id"])
        name = f"stop_{st['id']:02d}_{part // PER + 1}.jpg"
        sheet.save(SHEETS / name, quality=85)

(BUILD / "sheet_manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8")
print("sheets:", len(list(SHEETS.glob("*.jpg"))), "labels:", len(manifest))
