"""Step 2b: remove near-identical shots with deep image embeddings (DINOv2-small). Run after 02_quality.py.

Why: global perceptual hashes (02_quality.py) miss re-framed shots of the same scene (they score 20-40 bits apart),
so the film shows "repeated photos". Embeddings catch them.

Method (field-tested in a 2 h / 3,700-photo build; this script is a cleaned re-implementation, run it on a small
sample first): greedy by sharpness q (best first); drop a candidate when cosine similarity >= DEDUPE_COS with any
already-kept item taken within WINDOW_MIN minutes. Clips (keyframes in build/clipframes/*.jpg, made by 09_video.py or
your own ffmpeg grab) are compared with photos the same way when CLIPS=1.

Env: TRIP_ROOT/TRIP_BUILD, DEDUPE_COS (default 0.90; 0.92 = looser), WINDOW_MIN (30), CLIPS (0/1).
Needs: pip install torch transformers pillow numpy   (CPU is enough; model facebook/dinov2-small, ~90 MB).
Outputs: build/embeddings.npz (cache, keyed by file name), build/dedupe.json (kept/removed + nearest kept),
build/dedupe_calibration.jpg (pairs in score bands: left kept, right removed -> choose the threshold BY EYE).
"""
import json, os
from datetime import datetime, timedelta
from pathlib import Path
import numpy as np
from PIL import Image

ROOT = Path(os.environ.get("TRIP_ROOT", "."))
BUILD = Path(os.environ.get("TRIP_BUILD") or ROOT / "build")
THR = float(os.environ.get("DEDUPE_COS", "0.90"))
WINDOW = timedelta(minutes=float(os.environ.get("WINDOW_MIN", "30")))
WITH_CLIPS = os.environ.get("CLIPS", "0") == "1"

rows = json.loads((BUILD / "quality.json").read_text(encoding="utf-8"))
items = [dict(file=r["file"], t=r["t"], q=r["q"], thumb=BUILD / "thumbs" / (Path(r["file"]).stem + ".jpg"), kind="photo")
         for r in rows if r.get("t") and not r.get("blurry")]
if WITH_CLIPS:
    inv = json.loads((BUILD / "inventory.json").read_text(encoding="utf-8"))
    for i in inv:
        fr = BUILD / "clipframes" / (Path(i["file"]).stem + ".jpg")
        if i["file"].lower().endswith(".mp4") and i.get("time") and fr.exists():
            t = datetime.strptime(i["time"][:19], "%Y:%m:%d %H:%M:%S").isoformat()
            items.append(dict(file=i["file"], t=t, q=1e9, thumb=fr, kind="clip"))  # clips outrank photos when equal scenes
for it in items:
    it["dt"] = datetime.fromisoformat(it["t"])

# --- embeddings (cached) ---
cache_p = BUILD / "embeddings.npz"
cache = dict(np.load(cache_p, allow_pickle=True)) if cache_p.exists() else {}
todo = [it for it in items if it["file"] not in cache]
if todo:
    import torch
    from transformers import AutoModel
    model = AutoModel.from_pretrained("facebook/dinov2-small").eval()
    mean = np.array([0.485, 0.456, 0.406], dtype=np.float32); std = np.array([0.229, 0.224, 0.225], dtype=np.float32)

    def prep(p):
        im = Image.open(p).convert("RGB").resize((224, 224), Image.BICUBIC)
        return ((np.asarray(im, dtype=np.float32) / 255 - mean) / std).transpose(2, 0, 1)

    for i in range(0, len(todo), 32):
        batch = todo[i:i + 32]
        x = torch.from_numpy(np.stack([prep(b["thumb"]) for b in batch]))
        with torch.no_grad():
            e = model(pixel_values=x).last_hidden_state[:, 0].numpy()
        e /= np.linalg.norm(e, axis=1, keepdims=True)
        for b, v in zip(batch, e):
            cache[b["file"]] = v
        print(f"embedded {min(i + 32, len(todo))}/{len(todo)}", flush=True)
    np.savez(cache_p, **cache)

# --- greedy selection ---
order = sorted(items, key=lambda x: -x["q"])
kept, removed = [], []
for it in order:
    v = cache[it["file"]]
    best, best_s = None, -1.0
    for k in kept:
        if abs(k["dt"] - it["dt"]) <= WINDOW:
            s = float(v @ cache[k["file"]])
            if s > best_s:
                best, best_s = k, s
    if best is not None and best_s >= THR:
        removed.append(dict(file=it["file"], kept_as=best["file"], cos=round(best_s, 3), thumb=str(it["thumb"]), kthumb=str(best["thumb"])))
    else:
        kept.append(it)
(BUILD / "dedupe.json").write_text(json.dumps(dict(
    threshold=THR, window_min=WINDOW.total_seconds() / 60, kept=[k["file"] for k in sorted(kept, key=lambda x: x["dt"])],
    removed=[{k: v for k, v in r.items() if "thumb" not in k} for r in removed]), indent=1), encoding="utf-8")
print(f"candidates={len(items)} kept={len(kept)} removed={len(removed)} (cos>={THR}, window {WINDOW})")

# --- calibration sheet: pairs near the threshold, left = kept, right = removed ---
bands = [(0.88, 0.90), (0.90, 0.92), (0.92, 1.01)]
cells = []
rng = np.random.default_rng(1)
for lo, hi in bands:
    cand = []
    for it in order:
        for k in kept:
            if k is it or abs(k["dt"] - it["dt"]) > WINDOW:
                continue
            s = float(cache[it["file"]] @ cache[k["file"]])
            if lo <= s < hi:
                cand.append((s, k["thumb"], it["thumb"]))
                break
    if cand:
        cells.append((f"{lo:.2f}-{min(hi, 1.0):.2f}", [cand[i] for i in rng.choice(len(cand), min(6, len(cand)), replace=False)]))
if cells:
    from PIL import ImageDraw
    TW, TH = 320, 213
    sheet = Image.new("RGB", (2 * TW + 20, sum(len(c[1]) for c in cells) * (TH + 6) + 40 * len(cells)), (20, 20, 20))
    d = ImageDraw.Draw(sheet); y = 0
    for label, pairs in cells:
        d.text((8, y + 10), f"band {label}  (left kept | right would be removed)", fill=(240, 196, 109)); y += 40
        for s, a, b in pairs:
            for j, p in enumerate((a, b)):
                im = Image.open(p).convert("RGB"); im.thumbnail((TW, TH)); sheet.paste(im, (j * (TW + 20), y))
            d.text((2 * TW + 24 - 60, y + 4), f"{s:.3f}", fill=(255, 255, 255)); y += TH + 6
    sheet.save(BUILD / "dedupe_calibration.jpg", quality=85)
    print("calibration sheet:", BUILD / "dedupe_calibration.jpg")
