"""Step 8: build the master timeline (shared by both languages), SRT subtitles and music plan.
Outputs: build/timeline.json, build/subs_en.srt, build/subs_ru.srt"""
import json, re
from pathlib import Path

ROOT = Path(__import__("os").environ.get("TRIP_ROOT", "."))
BUILD = Path(__import__("os").environ.get("TRIP_BUILD") or ROOT / "build")

script = json.loads((BUILD / "script.json").read_text(encoding="utf-8"))
manifest = json.loads((BUILD / "sheet_manifest.json").read_text(encoding="utf-8"))
inv = {i["file"]: i for i in json.loads((BUILD / "inventory.json").read_text(encoding="utf-8"))}
aidx_path = BUILD / "audio_index.json"
aidx = json.loads(aidx_path.read_text(encoding="utf-8")) if aidx_path.exists() else {}

D_PHOTO = 8.5   # base seconds per photo
D_CLIP_MAX = 8.0
XF = 0.6        # dissolve overlap between items inside a segment
LEAD, TAIL = 1.0, 1.4  # narration starts LEAD s into a segment; keep TAIL s after it ends


def est(text):  # slow voice ~2.1 words/s
    return len(text.split()) / 2.1 + 0.6


def alen(lang, uid, text):
    v = aidx.get(f"{lang}/{uid}")
    return (v, False) if v else (est(text), True)


def short_desc(text, maxlen=125):
    """On-screen description: first sentence(s) of the narration, kept short."""
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    d = parts[0]
    if len(d) < 45 and len(parts) > 1:
        d = d + " " + parts[1]
    if len(d) > maxlen and "," in d[:maxlen]:
        d = d[:d[:maxlen].rfind(",")] + "."
    return d


def label_to_item(lab):
    key = lab.replace("V", " VID") if lab.endswith("V") else lab
    m = manifest[key]
    i = inv[m["file"]]
    kind = "video" if m["kind"] == "V" else "photo"
    return dict(label=lab, file=m["file"], kind=kind, w=i["w"], h=i["h"], src_dur=i["duration"])


units, narr = [], []  # narr: dict(uid, start, en_len, ru_len, en_text, ru_text, est)
t = 0.0


def add_narr(uid, start, en, ru):
    le, ee = alen("en", uid, en)
    lr, er = alen("ru", uid, ru)
    narr.append(dict(uid=uid, start=round(start, 2), en_len=round(le, 2), ru_len=round(lr, 2),
                     en=en, ru=ru, estimated=bool(ee or er)))
    return max(le, lr)


# title
units.append(dict(type="title", name="title", start=t, dur=6.0))
t += 6.0
# route map with intro narration
n = add_narr("intro", t + 0.8, script["intro"]["en"], script["intro"]["ru"])
dur = max(12.0, n + 2.4)
units.append(dict(type="route", name="route", start=round(t, 2), dur=round(dur, 2)))
t += dur

music = []  # (start, end, track, offset)
TRACKS = {"eastern": "Eastern Thought.mp3", "desert": "Desert City.mp3", "ethereal": "Ethereal Relaxation.mp3", "floating": "Floating Cities.mp3",
          "ascend": "Journey To Ascend.mp3", "road": "Old Road.mp3", "zen": "That Zen Moment.mp3", "touching": "Touching Moments Two - Higher.mp3",
          "balance": "Finding the Balance.mp3", "leaving": "Leaving Home.mp3", "mana": "Mana Two - Part 2.mp3"}
# per chapter: list of (first_segment_index (1-based), track, offset); chapter card follows the first entry
PLAN = {
    "C1": [(1, "ascend", 0)],                                   # Chimgan mountains: uplifting
    "C2": [(1, "zen", 0)],                                      # Mizdakhan / Gyaur-Kala: ancient, still
    "C3": [(1, "desert", 0), (3, "touching", 0)],               # Moynaq: desert, then somber piano at the ship graveyard
    "C4": [(1, "road", 0), (4, "zen", 330)],                    # Nukus, then Chilpik Dakhma
    "C5": [(1, "eastern", 0), (5, "balance", 0), (9, "floating", 0)],   # Khiva: day, afternoon, night
    "C6": [(1, "eastern", 140), (5, "ethereal", 600)],          # Khiva walls and palaces, calm dusk
    "C7": [(1, "mana", 0)],                                     # Fortresses of ancient Khorezm
    "C8": [(1, "leaving", 0)],                                  # Tashkent and farewell
}
music.append([0.0, t, "eastern", 0])  # title + route
seg_counter = 0
for ch in script["chapters"]:
    cid = ch["id"]
    cstart = t
    n = add_narr(f"{cid}_intro", t + 0.6, ch["intro_en"], ch["intro_ru"])
    cdur = max(4.0, n + 1.6)
    units.append(dict(type="card", name=f"card_{cid}", chapter=cid, start=round(t, 2), dur=round(cdur, 2)))
    t += cdur
    plan = PLAN[cid]
    cur_music = [cstart, None, plan[0][1], plan[0][2]]
    for si, sg in enumerate(ch["segments"], 1):
        for (first, trk, off) in plan[1:]:
            if si == first:
                cur_music[1] = t
                music.append(cur_music)
                cur_music = [t, None, trk, off]
        items = [label_to_item(l) for l in sg["labels"]]
        for it in items:
            it["d"] = D_PHOTO if it["kind"] == "photo" else min(D_CLIP_MAX, it["src_dur"] or D_CLIP_MAX)
        uid = f"{cid}_s{si:02d}"
        ne = alen("en", uid, sg["en"]); nr = alen("ru", uid, sg["ru"])
        nl = max(ne[0], nr[0])
        need = nl + LEAD + TAIL
        nI = len(items)
        sum_d = sum(i["d"] for i in items)
        raw = sum_d - (nI - 1) * XF
        if raw < need:
            clips = sum(i["d"] for i in items if i["kind"] == "video")
            photo_sum = sum(i["d"] for i in items if i["kind"] == "photo")
            target_photos = need + (nI - 1) * XF - clips
            if photo_sum > 0:
                k = target_photos / photo_sum
                for i in items:
                    if i["kind"] == "photo":
                        i["d"] = round(i["d"] * k, 3)
            else:
                k = (need + (nI - 1) * XF) / sum_d
                for i in items:
                    i["d"] = round(i["d"] * k, 3)
        L = sum(i["d"] for i in items) - (nI - 1) * XF
        narr.append(dict(uid=uid, start=round(t + LEAD, 2), en_len=ne[0], ru_len=nr[0], en=sg["en"], ru=sg["ru"],
                         estimated=bool(ne[1] or nr[1])))
        units.append(dict(type="segment", name=uid, chapter=cid, start=round(t, 2), dur=round(L, 2), items=items,
                          place_en=sg["place_en"], place_ru=sg["place_ru"],
                          desc_en=short_desc(sg["en"]), desc_ru=short_desc(sg["ru"])))
        t += L
        seg_counter += 1
    cur_music[1] = t
    music.append(cur_music)

# outro
n = add_narr("outro", t + 1.2, script["outro"]["en"], script["outro"]["ru"])
odur = max(8.0, n + 3.0)
units.append(dict(type="credits", name="credits", start=round(t, 2), dur=round(odur, 2)))
music.append([t, t + odur, "leaving", 300])
t += odur

timeline = dict(total=round(t, 2), units=units, narration=narr,
                music=[dict(start=round(a, 2), end=round(b, 2), track=TRACKS[tr], offset=off) for a, b, tr, off in music])
(BUILD / "timeline.json").write_text(json.dumps(timeline, indent=1, ensure_ascii=False), encoding="utf-8")


# ---- subtitles ----
def srt_time(x):
    ms = int(round(x * 1000))
    h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def chunks(text):
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    out = []
    for p in parts:  # split long sentences at commas to keep subtitles short
        if len(p) > 95 and "," in p:
            pos = [i for i, ch in enumerate(p) if ch == ","]
            cut = min(pos, key=lambda i: abs(i - len(p) // 2))
            out += [p[:cut + 1].strip(), p[cut + 1:].strip()]
        else:
            out.append(p)
    return [o for o in out if o]


for lang in ("en", "ru"):
    lines, k = [], 1
    for nr in narr:
        text, ln = nr[lang], nr[f"{lang}_len"]
        cs = chunks(text)
        tot = sum(len(c) for c in cs)
        cur = nr["start"]
        for c in cs:
            d = ln * len(c) / tot
            lines.append(f"{k}\n{srt_time(cur)} --> {srt_time(cur + d - 0.05)}\n{c}\n")
            k += 1
            cur += d
    (BUILD / f"subs_{lang}.srt").write_text("\n".join(lines), encoding="utf-8")

print(f"total runtime {t/60:.1f} min  units={len(units)}  segments={seg_counter}  music_entries={len(music)}")
print("estimated-audio narration units:", [n["uid"] for n in narr if n["estimated"]])
