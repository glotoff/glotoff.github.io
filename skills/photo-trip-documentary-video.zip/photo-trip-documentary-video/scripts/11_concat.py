"""Step 11: concatenate the rendered segments (stream copy) -> build/video_all.mp4.
Muxing audio/subtitles and the YouTube package is done by 14_package.py."""
import json, subprocess
from pathlib import Path

ROOT = Path(__import__("os").environ.get("TRIP_ROOT", "."))
BUILD = Path(__import__("os").environ.get("TRIP_BUILD") or ROOT / "build")
tl = json.loads((BUILD / "timeline.json").read_text(encoding="utf-8"))
missing = [u["name"] for u in tl["units"] if not (BUILD / "seg" / f"{u['name']}.mp4").exists()]
if missing:
    raise SystemExit(f"segments missing: {missing[:10]} ...")
lst = BUILD / "concat.txt"
lst.write_text("".join(f"file 'seg/{u['name']}.mp4'\n" for u in tl["units"]), encoding="utf-8")
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy",
                str(BUILD / "video_all.mp4")], check=True)
print("written", BUILD / "video_all.mp4")
