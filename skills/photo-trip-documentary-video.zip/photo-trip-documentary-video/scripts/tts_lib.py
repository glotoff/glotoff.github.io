"""Shared Gemini TTS helper. Reads the key from GEMINI_API_KEY (never stored on disk)."""
import time, wave
from pathlib import Path
from google import genai
from google.genai import types

# NOTE: any instruction text put in front of the script gets READ ALOUD by these TTS models, so none is used.
STYLE = {"en": "", "ru": ""}


def clean_pcm(data):
    """Drop the loud ~100 ms noise burst the API appends at the end of every clip, add a short fade-out."""
    import numpy as np
    a = np.frombuffer(data, dtype=np.int16).astype(np.float32)
    n = 240  # 10 ms
    k = len(a) // n
    rms = np.sqrt((a[:k * n].reshape(k, n) ** 2).mean(axis=1)) / 32768
    cut = len(a)
    i = k - 1
    while i > 0 and rms[i] > 0.25:
        i -= 1
    if i < k - 1:
        cut = (i + 1) * n
    a = a[:cut].copy()
    f = min(len(a), 1200)
    a[-f:] *= np.linspace(1, 0, f)
    return a.astype(np.int16).tobytes()


def synth(text, lang, out_path, model, voice, retries=6):
    client = genai.Client()
    cfg = types.GenerateContentConfig(
        response_modalities=["AUDIO"],
        speech_config=types.SpeechConfig(
            voice_config=types.VoiceConfig(
                prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=voice))))
    last = None
    for attempt in range(retries):
        try:
            r = client.models.generate_content(model=model, contents=STYLE[lang] + text, config=cfg)
            data = r.candidates[0].content.parts[0].inline_data.data
            data = clean_pcm(data)
            with wave.open(str(out_path), "wb") as w:
                w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000)
                w.writeframes(data)
            return len(data) / 2 / 24000
        except Exception as e:  # noqa
            last = e
            time.sleep(min(60, 5 * (attempt + 1)))
    raise RuntimeError(f"TTS failed: {last}")
