"""Step 9: render every timeline unit to build/seg/<name>.mp4 (1080p30, no audio), resumable.
Usage: python 09_video.py [name-prefix ...]   (e.g. C1_ title card_C1)"""
import json, os, subprocess, sys, textwrap
from pathlib import Path
from PIL import Image, ImageFilter, ImageOps, ImageEnhance

ROOT = Path(__import__("os").environ.get("TRIP_ROOT", "."))
BUILD = Path(__import__("os").environ.get("TRIP_BUILD") or ROOT / "build")
SRC = ROOT / __import__("os").environ.get("MEDIA_DIR", "photos-and-videos")
SEG = BUILD / "seg"; SEG.mkdir(exist_ok=True)
PLATES = BUILD / "plates"; PLATES.mkdir(exist_ok=True)
MOTION = ROOT / "motion"
NODE_X64 = __import__("os").environ.get("NODE_X64_DIR", "")
FONT = "C\\:/Windows/Fonts/segoeui.ttf"
FONTB = "C\\:/Windows/Fonts/segoeuib.ttf"
XF = 0.6
W, H = 1920, 1080
CW, CH = 2112, 1188  # 1.1x canvas

tl = json.loads((BUILD / "timeline.json").read_text(encoding="utf-8"))
only = sys.argv[1:]

ENC = ["-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-r", "30", "-g", "60",
       "-video_track_timescale", "15360", "-an", "-movflags", "+faststart",
       "-color_range", "tv", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709"]
TAG = "setparams=range=tv:colorspace=bt709:color_primaries=bt709:color_trc=bt709"
HLG_TO_SDR = ("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,"
              "zscale=t=bt709:m=bt709:r=tv,format=yuv420p")
_hlg = {}


def is_hlg(path):
    if path not in _hlg:
        r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=color_transfer",
                            "-of", "csv=p=0", str(path)], capture_output=True, text=True)
        _hlg[path] = "b67" in r.stdout or "smpte2084" in r.stdout
    return _hlg[path]


GRAD = PLATES / "_grad.png"
if not GRAD.exists():
    import numpy as np
    gh = 470
    a = (np.linspace(0, 1, gh) ** 1.6 * 150).astype("uint8")
    arr = np.zeros((gh, W, 4), dtype="uint8"); arr[..., 3] = a[:, None]
    Image.fromarray(arr, "RGBA").save(GRAD)


def run(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", **kw)
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-1500:])
    return r


def upright_size(it):
    if it["kind"] == "video":
        fr = BUILD / "clipframes" / (Path(it["file"]).stem + ".jpg")
        with Image.open(fr) as im:
            return im.size
    w, h = it["w"], it["h"]
    return (w, h)


def make_plate(it):
    """Return (plate_path, PW, PH). Photos only; orientation is baked in."""
    out = PLATES / (Path(it["file"]).stem + ".jpg")
    im = Image.open(SRC / it["file"])
    im = ImageOps.exif_transpose(im).convert("RGB")
    iw, ih = im.size
    asp = iw / ih
    if asp >= 1.0:
        if asp >= 1.78:
            ph = CH; pw = int(round(ph * asp))
        else:
            pw = CW; ph = int(round(pw / asp))
        plate = im.resize((pw, ph), Image.LANCZOS)
    else:
        bg = ImageOps.fit(im, (CW // 4, CH // 4), Image.BILINEAR).filter(ImageFilter.GaussianBlur(14))
        bg = bg.resize((CW, CH), Image.BICUBIC)
        bg = ImageEnhance.Brightness(bg).enhance(0.45)
        fh = 1010
        fw = int(round(fh * asp))
        fg = im.resize((fw, fh), Image.LANCZOS)
        plate = bg
        plate.paste(fg, ((CW - fw) // 2, (CH - fh) // 2))
        pw, ph = CW, CH
    if not out.exists():
        plate.save(out, quality=93)
    return out, plate.size[0], plate.size[1]


def pan_expr(idx, pw, ph, d):
    rx, ry = pw - W, ph - H
    if rx >= ry:   # wide plate: horizontal pan
        a, b = (0.0, 1.0) if idx % 2 == 0 else (1.0, 0.0)
        x0, x1 = a * rx, b * rx
        y0 = y1 = ry * 0.5
    else:           # tall plate: vertical pan with slight x drift
        a, b = (0.15, 0.75) if idx % 2 == 0 else (0.75, 0.15)
        y0, y1 = a * ry, b * ry
        x0 = x1 = rx * 0.5
    e = f"(3*pow(t/{d},2)-2*pow(t/{d},3))"
    return f"x='{x0:.1f}+({x1 - x0:.1f})*{e}':y='{y0:.1f}+({y1 - y0:.1f})*{e}'"


def render_segment(u):
    out = SEG / f"{u['name']}.mp4"
    if out.exists():
        return
    items = u["items"]
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-hide_banner"]
    chains = []
    for i, it in enumerate(items):
        d = it["d"]
        if it["kind"] == "photo":
            plate, pw, ph = make_plate(it)
            cmd += ["-loop", "1", "-framerate", "30", "-t", f"{d:.3f}", "-i", str(plate)]
            chains.append(f"[{i}:v]crop={W}:{H}:{pan_expr(i, pw, ph, d)},setsar=1,scale=in_range=pc:out_range=tv,format=yuv420p,fps=30[v{i}]")
        else:
            cmd += ["-t", f"{d:.3f}", "-i", str(SRC / it["file"])]
            sw, sh = upright_size(it)
            pre = (HLG_TO_SDR + ",") if is_hlg(SRC / it["file"]) else ""
            if sw / sh < 1.0:
                chains.append(
                    f"[{i}:v]{pre}split[a{i}][b{i}];"
                    f"[a{i}]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=28:4,eq=brightness=-0.18[bg{i}];"
                    f"[b{i}]scale=-2:1010[fg{i}];[bg{i}][fg{i}]overlay=(W-w)/2:(H-h)/2,setsar=1,format=yuv420p,fps=30[v{i}]")
            else:
                chains.append(f"[{i}:v]{pre}scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,format=yuv420p,fps=30[v{i}]")
    # xfade chain
    trans = ["fade", "fade", "dissolve", "fade", "fade", "smoothleft"]
    cur = "v0"; acc = items[0]["d"]
    for i in range(1, len(items)):
        nxt = f"x{i}"
        chains.append(f"[{cur}][v{i}]xfade=transition={trans[i % len(trans)]}:duration={XF}:offset={acc - XF:.3f}[{nxt}]")
        acc = acc + items[i]["d"] - XF
        cur = nxt
    L = acc
    def wrap(t, w):
        return chr(10).join(textwrap.wrap(t, w))
    texts = {"c1": u["place_en"], "c2": u["place_ru"], "c3": wrap(u["desc_en"], 74), "c4": wrap(u["desc_ru"], 80)}
    P = {}
    for k, v in texts.items():
        f = SEG / f"{u['name']}_{k}.txt"
        f.write_bytes(v.encode("utf-8"))
        P[k] = str(f).replace("\\", "/").replace(":", "\\:")
    t_end = min(L - 1.0, 11.5)
    alpha = f"if(lt(t,1.2),0,if(lt(t,1.7),(t-1.2)/0.5,if(lt(t,{t_end - 0.5:.2f}),1,if(lt(t,{t_end:.2f}),({t_end:.2f}-t)/0.5,0))))"
    sh = "shadowcolor=black@0.9:shadowx=2:shadowy=2:borderw=1:bordercolor=black@0.35"
    post = (f"[{cur}]eq=contrast=1.05:saturation=1.07:gamma=0.98[gr];[gr][gf]overlay=0:H-h:format=auto,"
            f"drawtext=fontfile='{FONTB}':textfile='{P['c1']}':fontcolor=white:fontsize=50:x=96:y=h-360:{sh}:alpha='{alpha}',"
            f"drawtext=fontfile='{FONT}':textfile='{P['c2']}':fontcolor=0xf2c46d:fontsize=32:x=98:y=h-300:{sh}:alpha='{alpha}',"
            f"drawtext=fontfile='{FONT}':textfile='{P['c3']}':fontcolor=white:fontsize=31:line_spacing=8:x=98:y=h-240:{sh}:alpha='{alpha}',"
            f"drawtext=fontfile='{FONT}':textfile='{P['c4']}':fontcolor=0xf2c46d:fontsize=27:line_spacing=6:x=98:y=h-140:{sh}:alpha='{alpha}',"
            f"fade=t=in:st=0:d=0.4,fade=t=out:st={L - 0.5:.3f}:d=0.5,{TAG}[vout]")
    chains.append(post)
    cmd += ["-loop", "1", "-framerate", "30", "-t", f"{L:.3f}", "-i", str(GRAD)]
    chains.append(f"[{len(items)}:v]format=rgba,fade=t=in:st=1.0:d=0.6:alpha=1,fade=t=out:st={t_end - 0.5:.2f}:d=0.6:alpha=1[gf]")
    cmd += ["-filter_complex", ";".join(chains), "-map", "[vout]", "-t", f"{L:.3f}"] + ENC + [str(out)]
    run(cmd)


def render_remotion(u):
    out = SEG / f"{u['name']}.mp4"
    if out.exists():
        return
    comp = {"title": "Title", "route": "RouteMap", "card": "ChapterCard", "credits": "EndCredits"}[u["type"]]
    props = {"lang": "en", "sec": round(u["dur"], 2)}
    if u["type"] == "card":
        props["chapterId"] = u["chapter"]
    pf = MOTION / "out" / f"props_{u['name']}.json"
    pf.parent.mkdir(parents=True, exist_ok=True)
    pf.write_text(json.dumps(props), encoding="utf-8")
    raw = MOTION / "out" / "clips" / f"{u['name']}.mp4"
    raw.parent.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ); env["PATH"] = NODE_X64 + os.pathsep + env["PATH"]
    cmd = f'npx remotion render src/index.ts {comp} "{raw}" --props="{pf}" --concurrency=2'
    r = subprocess.run(cmd, cwd=str(MOTION), env=env, shell=True, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0 or not raw.exists():
        raise RuntimeError(f"remotion failed {u['name']}: {(r.stdout + r.stderr)[-800:]}")
    run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw), "-vf", f"fps=30,scale={W}:{H}:in_range=pc:out_range=tv,format=yuv420p,{TAG}", "-t", f"{u['dur']:.3f}"] + ENC + [str(out)])


for u in tl["units"]:
    if only and not any(u["name"].startswith(p) for p in only):
        continue
    try:
        (render_segment if u["type"] == "segment" else render_remotion)(u)
        print("ok", u["name"], f"{u['dur']:.1f}s", flush=True)
    except Exception as e:  # noqa
        print("FAIL", u["name"], str(e)[:600], flush=True)
