import React from "react";
import { AbsoluteFill } from "remotion";
import data from "./data.json";

export const C = { bg: "#0b1d2a", bg2: "#12303f", gold: "#f2c46d", turq: "#3fb8af", text: "#f6efe0", dim: "#9fb3bd" };
export const SERIF = "Georgia, 'Times New Roman', serif";
export const SANS = "'Segoe UI', Arial, sans-serif";

export type Lang = "en" | "ru";

// 8-point star tiling, subtle Islamic-geometry background
export const Pattern: React.FC<{ opacity?: number }> = ({ opacity = 0.07 }) => (
  <AbsoluteFill style={{ opacity }}>
    <svg width="100%" height="100%" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid slice">
      <defs>
        <pattern id="p" width="120" height="120" patternUnits="userSpaceOnUse">
          <g fill="none" stroke={C.gold} strokeWidth="1.4">
            <rect x="30" y="30" width="60" height="60" />
            <rect x="30" y="30" width="60" height="60" transform="rotate(45 60 60)" />
            <circle cx="60" cy="60" r="14" />
          </g>
        </pattern>
      </defs>
      <rect width="1920" height="1080" fill="url(#p)" />
    </svg>
  </AbsoluteFill>
);

export const Backdrop: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <AbsoluteFill style={{ background: `radial-gradient(ellipse at 50% 40%, ${C.bg2} 0%, ${C.bg} 70%)` }}>
    <Pattern />
    {children}
  </AbsoluteFill>
);

// Map projection over a strip covering the trip
export const BOX = { lonMin: 57.8, lonMax: 71.0, latMin: 40.6, latMax: 44.2 };
export const project = (lat: number, lon: number, w: number, h: number) => {
  const x = ((lon - BOX.lonMin) / (BOX.lonMax - BOX.lonMin)) * w;
  const y = h - ((lat - BOX.latMin) / (BOX.latMax - BOX.latMin)) * h;
  return [x, y] as const;
};

export const wp = (id: string) => data.waypoints.find((w) => w.id === id)!;

// Schematic journey line: stops evenly spaced along a gentle wave (keeps labels readable)
export const ORDER = ["chimgan", "nukus", "mizdakhan", "moynaq", "chilpik", "khiva", "ayaz", "kyzyl", "tashkent"];
export const schemaPos = (i: number, w: number, h: number) => {
  const n = ORDER.length;
  const x = 110 + (i * (w - 220)) / (n - 1);
  const y = h / 2 + Math.sin(i * 0.95 + 0.4) * h * 0.26;
  return [x, y] as const;
};
