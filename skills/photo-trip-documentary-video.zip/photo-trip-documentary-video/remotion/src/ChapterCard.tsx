import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig, Easing } from "remotion";
import { Backdrop, C, Lang, SERIF, SANS, ORDER, schemaPos, wp } from "./theme";
import data from "./data.json";

const W = 1500, H = 300;

export const ChapterCard: React.FC<{ lang: Lang; chapterId: string; sec?: number }> = ({ lang, chapterId }) => {
  const f = useCurrentFrame();
  const { durationInFrames: D } = useVideoConfig();
  const ch = data.chapters.find((c) => c.id === chapterId)!;
  const here = wp(ch.wp);
  const title = ch.title_en;
  const titleRu = ch.title_ru;
  const day = ch.day_en + "  ·  " + ch.day_ru;
  const ease = Easing.out(Easing.cubic);
  const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
  const o1 = interpolate(f, [4, 24], [0, 1], { ...clamp, easing: ease });
  const y1 = interpolate(f, [4, 34], [24, 0], { ...clamp, easing: ease });
  const o2 = interpolate(f, [18, 40], [0, 1], clamp);
  const mapO = interpolate(f, [28, 55], [0, 1], clamp);
  const out = interpolate(f, [D - 24, D], [1, 0], clamp);
  const pulse = 1 + 0.25 * Math.sin(f / 5);
  const pts = ORDER.map((_, i) => schemaPos(i, W, H));
  const hi = ORDER.indexOf(ch.wp);
  const [hx, hy] = pts[hi];
  const hereName = here.en + " · " + here.ru;
  return (
    <Backdrop>
      <AbsoluteFill style={{ opacity: out, justifyContent: "center", alignItems: "center" }}>
        <div style={{ fontFamily: SANS, fontSize: 28, letterSpacing: 7, color: C.turq, textTransform: "uppercase", opacity: o1 }}>{day}</div>
        <div style={{ fontFamily: SERIF, fontSize: 100, color: C.gold, textAlign: "center", maxWidth: 1600, lineHeight: 1.1, margin: "26px 0 0", opacity: o1, transform: `translateY(${y1}px)` }}>{title}</div>
        <div style={{ fontFamily: SERIF, fontSize: 56, color: C.text, textAlign: "center", maxWidth: 1600, margin: "14px 0 0", opacity: o2 }}>{titleRu}</div>
        <div style={{ width: 360, height: 3, background: C.turq, margin: "36px 0", opacity: o2 }} />
        <svg width={W} height={H + 70} viewBox={`-40 -40 ${W + 80} ${H + 110}`} style={{ opacity: mapO, marginTop: 20 }}>
                    <polyline points={pts.map((p) => p.join(",")).join(" ")} fill="none" stroke={C.gold} strokeOpacity={0.35} strokeWidth={2} strokeDasharray="8 8" />
          {pts.map((p, i) => (
            <circle key={i} cx={p[0]} cy={p[1]} r={5} fill={C.dim} fillOpacity={0.6} />
          ))}
          <circle cx={hx} cy={hy} r={18 * pulse} fill={C.turq} fillOpacity={0.25} />
          <circle cx={hx} cy={hy} r={9} fill={C.gold} />
          <text x={hx} y={hy + 56} textAnchor="middle" fontFamily={SANS} fontSize={28} fill={C.text}>{hereName}</text>
        </svg>
      </AbsoluteFill>
    </Backdrop>
  );
};
