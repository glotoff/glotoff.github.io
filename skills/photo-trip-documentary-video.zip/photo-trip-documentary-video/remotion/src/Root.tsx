import React from "react";
import { Composition } from "remotion";
import { Title } from "./Title";
import { ChapterCard } from "./ChapterCard";
import { RouteMap } from "./RouteMap";
import { EndCredits } from "./EndCredits";
import { Test } from "./Test";

const common = { fps: 30, width: 1920, height: 1080 } as const;
const dur = ({ props }: { props: { sec?: number } }) => ({ durationInFrames: Math.max(30, Math.round((props.sec ?? 4) * 30)) });

export const Root: React.FC = () => (
  <>
    <Composition id="Test" component={Test} durationInFrames={60} {...common} />
    <Composition id="Title" component={Title} durationInFrames={180} defaultProps={{ lang: "en" as const }} {...common} />
    <Composition id="ChapterCard" component={ChapterCard} durationInFrames={120} defaultProps={{ lang: "en" as const, chapterId: "C1", sec: 4 }} calculateMetadata={dur} {...common} />
    <Composition id="RouteMap" component={RouteMap} durationInFrames={360} defaultProps={{ lang: "en" as const, sec: 12 }} calculateMetadata={dur} {...common} />
    <Composition id="EndCredits" component={EndCredits} durationInFrames={240} defaultProps={{ lang: "en" as const, sec: 8 }} calculateMetadata={dur} {...common} />
  </>
);
