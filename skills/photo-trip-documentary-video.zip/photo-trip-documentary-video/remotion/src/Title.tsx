import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, Easing } from "remotion";
import { Backdrop, C, Lang, SERIF, SANS } from "./theme";
import data from "./data.json";

export const Title: React.FC<{ lang: Lang }> = ({ lang }) => {
  const f = useCurrentFrame();
  const t = data.title;
    const main = "Uzbekistan";
  const mainRu = "Узбекистан";
  const subEn = t.sub_en;
  const subRu = t.sub_ru;
  const date = "October 2026  ·  Октябрь 2026";
  const ease = Easing.out(Easing.cubic);
  const o1 = interpolate(f, [8, 38], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ease });
  const y1 = interpolate(f, [8, 48], [30, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ease });
  const line = interpolate(f, [30, 70], [0, 520], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ease });
  const o2 = interpolate(f, [50, 85], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const o3 = interpolate(f, [75, 110], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const fade = interpolate(f, [150, 180], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const scale = interpolate(f, [0, 180], [1, 1.04]);
  return (
    <Backdrop>
      <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", opacity: fade, transform: `scale(${scale})` }}>
        <div style={{ fontFamily: SERIF, fontSize: 180, letterSpacing: 6, color: C.gold, opacity: o1, transform: `translateY(${y1}px)` }}>{main}</div>
        <div style={{ fontFamily: SERIF, fontSize: 84, letterSpacing: 4, color: C.text, opacity: o1, marginTop: 4 }}>{mainRu}</div>
        <div style={{ width: line, height: 3, background: C.turq, margin: "26px 0" }} />
        <div style={{ fontFamily: SERIF, fontStyle: "italic", fontSize: 48, color: C.text, opacity: o2 }}>{subEn}</div>
        <div style={{ fontFamily: SERIF, fontStyle: "italic", fontSize: 38, color: C.dim, opacity: o2, marginTop: 8 }}>{subRu}</div>
        <div style={{ fontFamily: SANS, fontSize: 30, letterSpacing: 8, color: C.dim, marginTop: 40, opacity: o3, textTransform: "uppercase" }}>{date}</div>
      </AbsoluteFill>
    </Backdrop>
  );
};
