import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig, Easing } from "remotion";
import { Backdrop, C, Lang, SERIF, SANS, ORDER as SCH, schemaPos } from "./theme";
import data from "./data.json";

const W = 1640, H = 520;

export const RouteMap: React.FC<{ lang: Lang; sec?: number }> = ({ lang }) => {
  const f = useCurrentFrame();
  const { durationInFrames: D } = useVideoConfig();
  const ids = SCH;
  const pts = ids.map((id) => {
    const w = data.waypoints.find((x) => x.id === id)!;
    return { id, w, p: schemaPos(SCH.indexOf(id), W, H) as readonly [number, number] };
  });
  const total = pts.length - 1;
  const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
  const prog = interpolate(f, [20, D - 60], [0, total], { ...clamp, easing: Easing.inOut(Easing.cubic) });
  const head = Math.floor(prog);
  const frac = prog - head;
  const cur = pts[Math.min(head, total)];
  const nxt = pts[Math.min(head + 1, total)];
  const px = cur.p[0] + (nxt.p[0] - cur.p[0]) * frac;
  const py = cur.p[1] + (nxt.p[1] - cur.p[1]) * frac;
  const title = "The Route  ·  Маршрут";
  const out = interpolate(f, [D - 30, D], [1, 0], clamp);
  const o = interpolate(f, [0, 25], [0, 1], clamp);
  const seen = new Set<string>();
  return (
    <Backdrop>
      <AbsoluteFill style={{ opacity: o * out, alignItems: "center", justifyContent: "center" }}>
        <div style={{ fontFamily: SERIF, fontSize: 84, color: C.gold, marginBottom: 20 }}>{title}</div>
        <svg width={W} height={H + 120} viewBox={`-60 -40 ${W + 120} ${H + 160}`}>
          {pts.slice(0, total).map((a, i) => {
            const b = pts[i + 1];
            const reach = Math.min(1, Math.max(0, prog - i));
            return (
              <line key={i} x1={a.p[0]} y1={a.p[1]} x2={a.p[0] + (b.p[0] - a.p[0]) * reach} y2={a.p[1] + (b.p[1] - a.p[1]) * reach}
                stroke={C.gold} strokeWidth={3.5} strokeLinecap="round" />
            );
          })}
          {pts.map((a, i) => {
            if (seen.has(a.id)) return null;
            seen.add(a.id);
            const shown = prog >= i - 0.01;
            const name = a.w.en;
            const nameRu = a.w.ru;
            const py0 = a.p[1];
            const prevY = i > 0 ? pts[i - 1].p[1] : py0 + 1;
            const nextY = i < total ? pts[i + 1].p[1] : py0 + 1;
            let dx = 0, dy = -28;
            if (py0 <= prevY && py0 <= nextY) { dx = 0; dy = -28; }
            else if (py0 >= prevY && py0 >= nextY) { dx = 0; dy = 46; }
            else if (nextY < py0) { dx = 62; dy = 46; }
            else { dx = 62; dy = -28; }
            return (
              <g key={a.id} opacity={shown ? 1 : 0.25}>
                <circle cx={a.p[0]} cy={a.p[1]} r={11} fill={shown ? C.turq : C.dim} />
                <text x={a.p[0] + dx} y={a.p[1] + dy} textAnchor="middle" fontFamily={SANS} fontSize={30} fill={C.text}>{name}</text>
                <text x={a.p[0] + dx} y={a.p[1] + dy + 30} textAnchor="middle" fontFamily={SANS} fontSize={22} fill={C.dim}>{nameRu}</text>
              </g>
            );
          })}
          <circle cx={px} cy={py} r={20} fill={C.gold} fillOpacity={0.9} />
        </svg>
      </AbsoluteFill>
    </Backdrop>
  );
};
