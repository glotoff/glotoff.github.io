import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { Backdrop, C, Lang, SERIF, SANS } from "./theme";
import data from "./data.json";

export const EndCredits: React.FC<{ lang: Lang; sec?: number }> = ({ lang }) => {
  const f = useCurrentFrame();
  const { durationInFrames: D } = useVideoConfig();
  const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
  const o = interpolate(f, [0, 30, D - 40, D], [0, 1, 1, 0], clamp);
  const head = "Thank you for travelling with us";
  const headRu = "Спасибо, что были с нами";
  const lines = [...data.credits.en, ...data.credits.ru];
  return (
    <Backdrop>
      <AbsoluteFill style={{ opacity: o, justifyContent: "center", alignItems: "center" }}>
        <div style={{ fontFamily: SERIF, fontSize: 76, color: C.gold, marginBottom: 6, textAlign: "center" }}>{head}</div>
        <div style={{ fontFamily: SERIF, fontSize: 52, color: C.text, marginBottom: 40, textAlign: "center" }}>{headRu}</div>
        {lines.map((l, i) => (
          <div key={i} style={{ fontFamily: SANS, fontSize: 26, color: i === 0 || i === 4 ? C.text : C.dim, margin: "5px 0" }}>{l}</div>
        ))}
      </AbsoluteFill>
    </Backdrop>
  );
};
