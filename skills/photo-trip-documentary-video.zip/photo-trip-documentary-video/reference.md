# Reference: pitfalls, fixes and publishing (v1.1)

Everything below was learned the hard way in two real builds (a 31-minute and a ~2-hour film). Each item = symptom -> cause -> fix.

## Narration (Gemini TTS)
| Symptom | Cause | Fix |
|---|---|---|
| Narrator reads "Read this as a warm, calm narrator..." aloud | TTS models speak any instruction placed before the text | No instruction prefix at all. Charon is calm by default. Check with `12_stt_check.py` (transcribe first 12 s with `gemini-2.5-flash`). |
| Click/"pshshs" at the start and end of every clip | The API adds a loud (rms ~0.5) burst: ~5 ms at the start, ~120 ms at the end | Silence the start burst (do not trim: keeps durations), cut the end burst, 20-30 ms fades (`tts_lib.clean_pcm`, `13_fix_clicks.py`, `afade=t=in:d=0.03` per clip in the mix). |
| 429 RESOURCE_EXHAUSTED after ~100 clips | Tier-1 limit: 100 requests/day/model, failed retries count | Use the Batch API (`client.batches.create(model, src=[{contents, config}...])`, poll, read `dest.inlined_responses`). Do not loop retries on a dead quota. |
| Voice sounds rushed (~190 wpm) | Model default pace | `ffmpeg -af atempo=0.92` per clip, then recompute durations. |
| Cost | Standard $9 / 1M audio tokens (3.8 flash, 25 tokens per second of audio), batch half price | A 17-minute narration x2 languages costs well under $1. |
Mixing models between clips changes the voice; keep one model for all clips of a film.

## Video
- **VLC shows only sound / Windows Media Player works:** mixed colour tags between segments (phone HDR HLG clips yuv420p tv bt2020
  vs JPEG-derived yuvj420p full range). Tone-map HLG (`zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p`),
  convert JPEG with `scale=in_range=pc:out_range=tv`, and tag every output `setparams=range=tv:colorspace=bt709:color_primaries=bt709:color_trc=bt709` + `-color_range tv -colorspace bt709 ...`.
- **drawtext textfile shows garbled multi-line text on Windows:** Python wrote CRLF. Write the file with `write_bytes(text.encode())` (LF only).
- Readability on bright photos: overlay a transparent-to-black gradient PNG with alpha fade instead of a hard box.
- Remotion has no Windows ARM64 compositor: run it with an x64 Node (`NODE_X64_DIR`). Pass props with `--props=<file>`.
- `alimiter` autoscales unless `level=0`; `loudnorm` can overshoot after AAC encode: leave 2 dB headroom (limit 0.72-0.76).

## Subtitles and containers
- MP4 `mov_text` tracks are NOT shown by Windows Media Player and are unreliable in VLC; MKV with `srt` streams works in VLC.
- Sidecar `.srt` for Windows players must be UTF-8 **with BOM** and CRLF, otherwise Cyrillic shows as mojibake.
- `YouTube ignores embedded subtitle and extra audio tracks`. Plain UTF-8 SRT (no BOM) for YouTube.

## Music
- incompetech.com lists tracks with JavaScript; fetching the page returns an empty shell. Use a real browser tool, search by keyword
  (e.g. "desert", "ambient", "piano"), then download `https://incompetech.com/music/royalty-free/mp3-royaltyfree/<URL-encoded Title>.mp3`
  (some titles 404 - skip them). License: CC BY 4.0, attribution mandatory (end card + description).
- Measure each track with `ebur128` and apply per-track gain (target about -19.5 LUFS) before mixing; downloads range from -28 to -11 LUFS.
- Plan music per location/theme (title, mountains, ancient sites, desert/somber, bazaar day, night, finale), switch at segment boundaries,
  use different offsets when a track returns.

## Facts and locations
- Phone GPS can be wrong (one day had coordinates in another country): use the median cluster, sanity-check with the user.
- Reverse geocoding gives streets, not monuments; confirm names via web search and hedge anything unverified in the script.

## YouTube publishing (manual steps)
1. studio.youtube.com -> Create -> Upload -> `<NAME>_<VERSION>_EN.mp4` (single audio). Title, description with music credits, Unlisted first.
2. Content -> video -> Subtitles: Add language English -> Upload file -> With timing -> `subs_en.srt` -> Publish. Repeat for Russian.
3. Languages page: Russian row -> Audio -> Add -> `Audio_RU.m4a` (multi-language audio needs an eligible channel; fallback:
   upload the `_RU.mp4` as a separate video).
4. Check signed-out: gear -> Subtitles and Audio track; then set Public.
Automation: YouTube Data API v3 (`videos.insert`, `captions.insert`, `thumbnails.set`) can upload video + subtitles; extra audio tracks
are, to my knowledge, Studio-only. Uploads from unaudited API projects may be forced private.

## Photo selection: repeated-looking shots (biggest lesson of the 2-hour build)
- Symptom: the film shows several near-identical shots in a row (same rock from slightly different angles).
- Cause: global pHash (8x8, threshold ~14 bits, compared only inside one GPS stop against the last 6 picks) scores re-framed
  shots 20-40 bits apart; GPS jitter splits one scene into two stops (never compared); clips were never compared with photos.
- Fix (`scripts/02b_dedupe_embeddings.py`): DINOv2-small embedding per thumbnail (224x224 bicubic, ImageNet mean/std, CLS token,
  L2-normalised), greedy by sharpness, drop if cosine >= 0.90 with any kept item within 30 minutes (no cross-day compare needed).
  Measured: 2,906 non-blurry candidates -> 1,932 kept at 0.90 (2,118 at 0.92).
- DINOv2 scores are high for any landscape, so do not trust the distribution: look at the calibration sheet (pairs per score band)
  and decide by eye. Tell the user up front that strict dedupe shortens the film (135 -> 108 min at 2.5 s/photo); options: shorter
  film, or 3 s per photo with a looser threshold. Do not backfill with similar photos.
- Still open: embed one keyframe per clip (`CLIPS=1`) so clips are compared with photos and each other; the embedding script
  here is a cleaned re-implementation - its selection logic was tested with stand-in vectors, the DINOv2 step itself must be run
  and checked on a small sample first.

## Pipeline hygiene
- Keep each step a script with a cache; key caches by file name. Embeddings in `embeddings.npz`, geocoding in `geocache.json`.
- Segments are stored per unit; when the selection changes the unit indices change -> rebuild or key by file name.
- Use `ffprobe` on every rendered segment for the real duration; metadata durations were off by up to a few frames and the video
  came out 5 s shorter than the timeline.
- One env var for the build folder (`TRIP_BUILD`) lets you start a clean build (`build` -> `build4`) without editing scripts.
- Windows: ffmpeg from winget lives in `%LOCALAPPDATA%\Microsoft\WinGet\Links` (add to PATH in each shell); exiftool via `EXIFTOOL`;
  the scripts read media from `MEDIA_DIR` (default `photos-and-videos`; a folder junction also works).
- This ffmpeg build rejected `-filter_complex_script`; use `-/filter_complex <file>` for long graphs.

## Narration generation (large films)
- Facts: `gemini-3.8-flash` with the `google_search` tool gave grounded stories (144 of 155 had sources); `gemini-2.5-flash` also works;
  `gemini-3.8-pro` returned 404 on one key. Ask for TOPIC/EN/RU lines only, omit unverifiable claims, names, ages, private details.
- Length control: ~2.35 EN words/s, ~1.95 RU words/s - give the model the word target per scene, reject outputs < 60% of it.
- TTS in bulk: Batch API (`batchGenerateContent`, voice Charon, `responseModalities: AUDIO`). Synchronous REST hit 429 after ~26
  clips; the Python SDK rejected `speechConfig` once (400) -> use REST. 155 clips/language took ~10 min in one batch.
  Response audio is WAV (strip RIFF header) or raw PCM.
- Verification: speech-to-text of spread samples (`gemini-2.5-flash`, mp3 at 64 kbps) vs the script: 0.84-0.96 similarity is fine.

## Audio mix details
- Trim leading/trailing silence of each music track before looping (silenceremove + areverse trick); untrimmed edges made 2-3 s gaps.
- With `-ss` offsets the loop duration must shrink by the offset, otherwise the bed is shorter than the film (8 minutes lost once).
  Assert bed >= film length. Add `-t <total>` on the output.
- Ducking: `sidechaincompress` threshold 0.02, ratio 8-10, attack 20 ms, release 500-700 ms; narration gain ~1.6, music ~0.8.
- Final chain `loudnorm=I=-17:TP=-2:LRA=9` then `alimiter`. A low ceiling and short attack worked: `limit=0.55:attack=1:release=50`
  gave peaks of -3.3/-3.4 dBFS; the default 0.7 let one language reach +0.1 dBFS after AAC. Always measure the encoded file
  (`ebur128=peak=true`): target -17 LUFS, peak <= -2 dBFS.

## Maps, chapters, cards
- Route map: equirectangular on a country/state GeoJSON drawn with Pillow; route = in-region stops in time order (out-of-region stops
  get no minimap). Animate by piping rawvideo frames to ffmpeg. Chapter interlude: ~4 s map of the location; 280 px minimap
  overlay per stop; the chapter description overlays the chapter's first photo for the whole narration (pick it by file name).
- End-card credit text wider than ~1,700 px must wrap onto two lines; check the last frame - outro text gets cut off otherwise.
- Known rough spots: straight-line routes with stray GPS spurs; indoor/car photos make poor chapter openers; facts come from
  search grounding, not a fact-check (tell the user to spot-check); the tooling cannot listen to the result - the user must
  check voice quality and balance.

## Packaging extras
- Add chapter timestamps (from `timeline.json`) to `youtube/README.txt` for the video description.
- Sidecar SRTs: UTF-8 with BOM and CRLF for Windows players; plain UTF-8 for YouTube.
- Say in the README which stories are grounded and which are general local colour.

## Security
- API keys only in environment variables, inline per command; never in files, logs or commits. Rotate keys that were pasted into chat.
- Delete only specific files you created; never `rm` globs of the project folder.
