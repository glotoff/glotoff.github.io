---
name: photo-trip-documentary-video
description: Turn a folder of trip photos and short clips (with GPS) into a professional documentary film (30-35 min main cut, or a longer story film) with music, AI narration in two languages (two audio tracks), two subtitle tracks, animated title/chapter/map cards, and a ready-to-upload YouTube package. Use when asked to "make a video from my trip photos", "create a documentary / slideshow with narration and music", or to add narration, subtitles, multi-language audio or a YouTube upload package to a photo video.
license: MIT
version: 1.1.0
---

# Photo trip documentary video

End-to-end pipeline, proven on two real builds: a 7-day trip (1,470 photos + 39 clips -> 31.5 min film) and a ~2 h
trip film (about 3,700 photos + 290 clips) - both with English + Russian narration, EN + RU subtitles, 1080p.
Works with any AI coding agent that can run shell commands, read images and edit files. Scripts are in `scripts/`
(Python + ffmpeg), animated cards in `remotion/` (React). Read `reference.md` BEFORE starting: it lists the pitfalls
that cost the most time (repeated photos, spoken TTS prompts, click/noise bursts, colour/VLC, limiter peaks, YouTube).

## Requirements
- ffmpeg 6+ (zoompan, xfade, drawtext, sidechaincompress, loudnorm, alimiter, zscale/tonemap), ffprobe.
  Windows: `winget install Gyan.FFmpeg` puts it in `%LOCALAPPDATA%\Microsoft\WinGet\Links` - add that to PATH in every shell.
- exiftool (not on PATH by default on Windows: set `EXIFTOOL` to its full path).
- Python 3.10+ with Pillow, pillow-heif, numpy, imagehash, requests, google-genai. Optional for smart de-duplication:
  `torch` + `transformers` (CPU is enough; not available for every Windows ARM64 Python - then fall back to pHash only).
- Node 20/22 + Remotion 4 for animated cards (optional; hybrid approach). On Windows ARM64 use an x64 Node build.
- A Gemini API key in the env var `GEMINI_API_KEY` (Google AI Studio). Never write it to a file or commit it.
  If a user pastes a key in chat, use it inline per command and tell them to rotate it afterwards.
- Environment variables read by every script: `TRIP_ROOT` (project folder), `MEDIA_DIR` (media folder name inside it,
  default `photos-and-videos`), `TRIP_BUILD` (build folder, default `<TRIP_ROOT>/build`; use a new value to start a clean
  build without editing scripts), `EXIFTOOL`, `NODE_X64_DIR`, `VERSION`, `NAME`, `TITLE`.

## Ask the user first (once, briefly - these change the whole build)
1. **Length vs. repeated photos.** Strict de-duplication shortens the film (a real build dropped from 135 to 108 min at
   2.5 s/photo). Offer: accept a shorter film, or raise seconds per photo (3 s) with a looser threshold. Never "backfill"
   with similar photos - that brings the repeats back. Default main cut 30-35 min.
2. Narration density (stories per chapter, or a share of runtime such as ~70%) and the language list. Each language = one
   more TTS batch, one more audio track, one more SRT.
3. Short video clips mixed with photos (default yes).
4. Voice/model. Default `gemini-3.8-flash-tts`, voice "Charon". Music: choose royalty-free tracks yourself
   (CC BY 4.0 Kevin MacLeod / incompetech) - credit is mandatory.
5. Privacy: the film shows GPS-derived place names - confirm they may be published.
6. Where it will be published (YouTube needs a different package than local playback).
7. Key handling: key via environment only; rotate it if it was ever pasted in chat.

## Pipeline (run from the `scripts/` folder, one step at a time, check output after each)
Every step caches in the build folder and is resumable. Key caches by FILE NAME, never by list index (indices change
whenever the selection changes).
1. `01_inventory.py` exiftool -> `build/inventory.json` (time, GPS, camera, size). Drop screenshots/tiny files.
2. `02_quality.py` sharpness (Laplacian variance), exposure, perceptual-hash burst grouping -> `quality.json` + thumbnails.
   `02b_dedupe_embeddings.py` removes near-identical RE-FRAMED shots with DINOv2 embeddings (cosine >= 0.90 within
   30 min, best sharpness kept) and writes a calibration contact sheet: look at it and pick the threshold by eye
   (0.92 clearly same shot, 0.90-0.92 mostly same spot, 0.88-0.90 mixed). Compare clips (`CLIPS=1`) with photos too.
3. `03_geocode.py` cluster by GPS+time into stops, Nominatim reverse geocode (1 req/s, cached in `geocache.json`; slow:
   ~10 min per 300 stops, run in background once). Landmarks come out wrong or as street names: confirm facts with web
   search; some phones embed wrong coordinates (check outliers). Photos without GPS cannot be placed on the map.
4. `04_contactsheets.py` labelled contact sheets per stop. LOOK at them (read images) and pick the best photos + clip
   moments into `build/picks.txt`. Keep a mix of wide, detail, people, POV. Avoid meals/hotel rooms/car interiors as
   chapter openers - prefer outdoor or GPS-confirmed landmark shots.
5. `05_storyboard.py` -> `storyboard.json` chapters/segments. Write narration per segment in each language
   (`06_script_EXAMPLE_uzbekistan.py` shows the format). For large films let a model draft stories with grounding
   (`gemini-3.8-flash` + `google_search` tool): ask for TOPIC/EN/RU lines only, give a target word count per scene
   (about 2.35 EN words/s, 1.95 RU words/s), reject outputs under 60% of it, tell it to omit anything unverifiable and
   private details (names, ages), keep grounding source URLs in a log (not spoken) and say in the README that
   un-grounded stories are general local colour. Show the user chapters + sample narration before generating audio,
   and tell them to spot-check facts.
6. Narration audio: `07b_tts_batch.py submit` then `... collect` (Gemini **Batch API**: avoids the 100 requests/day/model
   cap, half price; if the SDK rejects `speechConfig` use REST `batchGenerateContent`). `tts_lib.clean_pcm` strips the
   API's noise bursts and the WAV header. NEVER put style instructions in the text: the model reads them aloud. Slow the
   clips ~8% (`atempo=0.92`) for a calm pace. `12_stt_check.py` transcribes clip starts to prove no prompt is spoken;
   compare spread samples with the script (similarity 0.84-0.96 is normal: spelling/number format).
7. `08_timeline.py` single shared timeline for all languages: segment length = max(narration in all languages) + 1.0 s lead
   + 1.4 s tail, photos 2-8.5 s each (as agreed), 0.6 s xfades; writes `timeline.json`, `subs_<lang>.srt` and the music
   plan (`PLAN` dict: one track per location/theme - edit it). Use REAL durations from `ffprobe` on each rendered
   segment, not metadata (metadata was off by frames -> video 5 s short).
8. `09_video.py` renders every unit to `build/seg/*.mp4` (resumable): Ken-Burns pans on 1.1x plates, portrait photos on
   blurred backgrounds, HLG/HDR clips tone-mapped to SDR, all outputs tagged bt709 TV range (`-c copy` concat needs
   identical params; GPU encoders like `h264_nvenc -cq 23 -g 30` are fine), on-screen place name + short description in
   two languages over a gradient. Cards/title/map/credits come from Remotion (`remotion/`). Chapter-intro text goes on
   the chapter's first photo, chosen by file name.
9. `10_audio.py` mixes per-track-normalised music + narration with sidechain ducking, loudnorm, a limiter with headroom,
   one AAC per language. Trim leading/trailing silence of music tracks before looping, and assert the music bed is at
   least as long as the film (offsets shorten the loop!). Always `-t <total>` so audio ends with video.
10. `11_concat.py` joins segments -> `video_all.mp4`; `14_package.py` builds `<VERSION>/` with: full MKV + MP4
    (2 audio, 2 subtitle tracks), sidecar `.srt` (UTF-8 **with BOM**, CRLF for Windows players), and `youtube/`:
    EN video (single audio), `Audio_<lang>.m4a`, plain-UTF-8 SRTs, fallback second-language video, README with credits
    (add chapter timestamps for the description).
11. Verify (below), then give the user the YouTube steps from `reference.md`.

## Rules for every change
- Create a NEW version folder (`v1`, `v2`, ...); never overwrite the previous deliverables.
- If only audio changes, keep clip durations identical (silence bursts instead of trimming) so no video re-render is needed.
- Do not re-render segments unless their duration or content changed; cache by file name.
- Report faithfully what was and was not verified; you cannot hear audio or run every player - say so. Never say
  "checks pass" for a stage you did not run (a length check once found truncated audio after loudness checks had passed).

## Verification checklist (do all, report exactly what ran)
- `ffprobe`: full file = 1 video, 2 audio, 2 subtitle streams, language tags; video, both audio and both subtitle
  tracks match `timeline.json total` within 0.1 s.
- Video: pix_fmt yuv420p, range tv, bt709 on the final file AND on every segment (mixed tags break VLC).
- Loudness per language with `ffmpeg -af ebur128=peak=true`: about -17 LUFS, peak <= -2 dBFS AFTER AAC encode.
- Silence scan: no silence > 1.5 s at -50 dB except where planned. Music bed covers the whole film.
- First 20 ms of each narration clip is silent (no click); STT check shows no spoken prompt.
- Frames: view chapter starts, map frames, cards and the LAST frame (outro text gets cut off unless wrapped).
- Similarity check on the final photo sequence: max neighbour similarity inside the window stays below the threshold.
- Subtitle files display Cyrillic correctly (BOM for Windows players). Credits present in end card and description.
