#!/usr/bin/env node
// Copies the bundled skill folder into a skills directory.
// Usage: npx -y <tgz-url> [--project] [--dir <path>] [--force]
const fs = require("fs"), path = require("path"), os = require("os");
const NAME = "photo-trip-documentary-video";
const args = process.argv.slice(2);
const flag = (f) => args.includes(f);
const val = (f) => { const i = args.indexOf(f); return i >= 0 ? args[i + 1] : null; };
if (flag("--help") || flag("-h")) {
  console.log(`Install the "${NAME}" skill.\n\n  (default)       ~/.claude/skills/${NAME}   (Claude Code, all projects)\n  --project       ./.claude/skills/${NAME}   (current project only)\n  --dir <path>    <path>/${NAME}             (any other agent/folder)\n  --force         overwrite an existing install`);
  process.exit(0);
}
const base = val("--dir") ? path.resolve(val("--dir"))
  : flag("--project") ? path.join(process.cwd(), ".claude", "skills")
  : path.join(os.homedir(), ".claude", "skills");
const dest = path.join(base, NAME);
const src = path.join(__dirname, "skill", NAME);
if (fs.existsSync(dest) && !flag("--force")) {
  console.error(`Already installed at ${dest}\nRe-run with --force to overwrite.`);
  process.exit(1);
}
fs.mkdirSync(base, { recursive: true });
fs.cpSync(src, dest, { recursive: true, force: true });
console.log(`Installed "${NAME}" -> ${dest}`);
console.log(`Next: ask your agent "Make a documentary video from my trip photos" (it reads ${path.join(dest, "SKILL.md")}).`);
