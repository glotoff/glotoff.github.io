"""Step 3: cluster kept photos/videos into stops by time+GPS, reverse-geocode -> build/stops.json"""
import json, math, time
from datetime import datetime
from pathlib import Path
import requests

ROOT = Path(__import__("os").environ.get("TRIP_ROOT", "."))
BUILD = ROOT / "build"
CACHE = BUILD / "geocache.json"
UA = "trip-video/1.0 (personal photo project)"


def hav(a, b):
    R = 6371000
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dp, dl = p2 - p1, math.radians(b[1] - a[1])
    x = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(x))


def pt(t):
    try:
        return datetime.strptime(t[:19], "%Y:%m:%d %H:%M:%S")
    except Exception:
        return None


inv = {i["file"]: i for i in json.loads((BUILD / "inventory.json").read_text(encoding="utf-8"))}
q = {r["file"]: r for r in json.loads((BUILD / "quality.json").read_text(encoding="utf-8"))}

items = []
for f, i in inv.items():
    if i["screenshot"]:
        continue
    if i["kind"] == "photo" and not (f in q and q[f]["keep"]):
        continue
    t = pt(i["time"]) if i["time"] else None
    if t is None:
        # fall back to filename date/time: 20261013_103311
        try:
            t = datetime.strptime(f[:15], "%Y%m%d_%H%M%S")
        except Exception:
            continue
    items.append(dict(file=f, kind=i["kind"], t=t, lat=i["lat"], lon=i["lon"], camera=i["camera"],
                      q=q.get(f, {}).get("q"), blurry=q.get(f, {}).get("blurry", False),
                      w=i["w"], h=i["h"], duration=i["duration"]))
items.sort(key=lambda x: x["t"])

# cluster: new stop if >75 min gap or >400 m from stop centroid
stops = []
for it in items:
    cur = stops[-1] if stops else None
    if it["lat"] is not None:
        pos = (it["lat"], it["lon"])
    else:
        pos = None
    new = cur is None
    if cur is not None:
        gap = (it["t"] - cur["end"]).total_seconds() / 60
        if gap > 75:
            new = True
        elif pos and cur["center"] and hav(pos, cur["center"]) > 400:
            new = True
    if new:
        cur = dict(items=[], pts=[], center=None, start=it["t"], end=it["t"])
        stops.append(cur)
    cur["items"].append(it)
    cur["end"] = it["t"]
    if pos:
        cur["pts"].append(pos)
        cur["center"] = (sum(p[0] for p in cur["pts"]) / len(cur["pts"]), sum(p[1] for p in cur["pts"]) / len(cur["pts"]))

# merge stops with < 3 items into the previous one if close in time (<75min) and near
merged = []
for s in stops:
    if merged and len(s["items"]) < 3 and (s["start"] - merged[-1]["end"]).total_seconds() < 75 * 60:
        m = merged[-1]
        m["items"] += s["items"]; m["end"] = s["end"]; m["pts"] += s["pts"]
    else:
        merged.append(s)
stops = merged

cache = json.loads(CACHE.read_text(encoding="utf-8")) if CACHE.exists() else {}
s = requests.Session(); s.headers["User-Agent"] = UA
out = []
for n, st in enumerate(stops):
    if st["center"] is None:
        geo = {}
    else:
        key = f"{st['center'][0]:.4f},{st['center'][1]:.4f}"
        if key not in cache:
            r = s.get("https://nominatim.openstreetmap.org/reverse",
                      params=dict(lat=st["center"][0], lon=st["center"][1], format="jsonv2", zoom=18,
                                  addressdetails=1, namedetails=1),
                      headers={"Accept-Language": "en"}, timeout=30)
            cache[key] = r.json() if r.ok else {}
            time.sleep(1.1)
        geo = cache[key]
    a = geo.get("address", {})
    out.append(dict(
        id=n, day=st["start"].strftime("%Y-%m-%d"), start=st["start"].isoformat(), end=st["end"].isoformat(),
        center=st["center"], count=len(st["items"]),
        place=geo.get("name") or a.get("tourism") or a.get("amenity") or a.get("road"),
        display=geo.get("display_name"),
        city=a.get("city") or a.get("town") or a.get("village") or a.get("county"),
        region=a.get("state") or a.get("region"),
        category=geo.get("category"), type=geo.get("type"),
        files=[dict(file=i["file"], kind=i["kind"], t=i["t"].isoformat(), camera=i["camera"], q=i["q"],
                    blurry=i["blurry"], w=i["w"], h=i["h"], duration=i["duration"]) for i in st["items"]],
    ))
    CACHE.write_text(json.dumps(cache, indent=1), encoding="utf-8")

(BUILD / "stops.json").write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
print(f"items={len(items)} stops={len(out)}")
for o in out[:200]:
    print(o["id"], o["day"], o["start"][11:16], o["count"], "|", o["city"], "|", o["place"])
