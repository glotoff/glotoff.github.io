"""Build versioned deliverables in <TRIP_ROOT>/<VERSION>/ : full MKV+MP4 (2 audio, 2 subtitle tracks), YouTube package
(EN video, RU audio, SRTs, RU fallback video, README with credits). Env: VERSION (default v1), TITLE, NAME."""
import json, subprocess
from pathlib import Path
ROOT = Path(__import__("os").environ.get("TRIP_ROOT", ".")); BUILD = ROOT / "build"
import os
VERSION = os.environ.get("VERSION", "v1"); NAME = os.environ.get("NAME", "Trip"); TITLE = os.environ.get("TITLE", "My trip")
V = ROOT / VERSION; YT = V / "youtube"; YT.mkdir(parents=True, exist_ok=True)
tl = json.loads((BUILD / "timeline.json").read_text(encoding="utf-8"))
video = BUILD / "video_all.mp4"
missing = [u["name"] for u in tl["units"] if not (BUILD / "seg" / f"{u['name']}.mp4").exists()]
assert not missing, missing
def ff(*a): subprocess.run(["ffmpeg", "-y", "-loglevel", "error", *a], check=True)
meta = ["-metadata:s:a:0", "language=eng", "-metadata:s:a:0", "title=English", "-metadata:s:a:1", "language=rus", "-metadata:s:a:1", "title=Русский",
        "-metadata:s:s:0", "language=eng", "-metadata:s:s:0", "title=English", "-metadata:s:s:1", "language=rus", "-metadata:s:s:1", "title=Русский",
        "-disposition:a:0", "default", "-disposition:a:1", "0", "-disposition:s:0", "0", "-disposition:s:1", "0", "-metadata", f"title={TITLE}"]
ins = ["-i", str(video), "-i", str(BUILD / "audio_en.m4a"), "-i", str(BUILD / "audio_ru.m4a"), "-i", str(BUILD / "subs_en.srt"), "-i", str(BUILD / "subs_ru.srt")]
maps = ["-map", "0:v", "-map", "1:a", "-map", "2:a", "-map", "3:0", "-map", "4:0"]
ff(*ins, *maps, "-c:v", "copy", "-c:a", "copy", "-c:s", "mov_text", *meta, "-movflags", "+faststart", str(V / f"{NAME}_{VERSION}.mp4"))
ff(*ins, *maps, "-c:v", "copy", "-c:a", "copy", "-c:s", "srt", *meta, str(V / f"{NAME}_{VERSION}.mkv"))
for lang, name in (("en", "EN"), ("ru", "RU")):
    ff("-i", str(video), "-i", str(BUILD / f"audio_{lang}.m4a"), "-map", "0:v", "-map", "1:a", "-c", "copy",
       "-metadata:s:a:0", f"language={'eng' if lang=='en' else 'rus'}", "-movflags", "+faststart", str(YT / f"{NAME}_{VERSION}_{name}.mp4"))
ff("-i", str(BUILD / "audio_ru.m4a"), "-c", "copy", str(YT / "Audio_RU.m4a"))
for lang in ("en", "ru"):
    t = (BUILD / f"subs_{lang}.srt").read_text(encoding="utf-8-sig")
    (YT / f"subs_{lang}.srt").write_text(t, encoding="utf-8", newline="\n")                 # for YouTube (plain UTF-8)
    (V / f"{NAME}_{VERSION}.{lang}.srt").write_bytes(b"\xef\xbb\xbf" + t.replace("\r\n", "\n").replace("\n", "\r\n").encode("utf-8"))  # for Windows players
credits = (ROOT / "music" / "CREDITS.md").read_text(encoding="utf-8") if (ROOT / "music" / "CREDITS.md").exists() else ""
(YT / "README.txt").write_text(f"""YouTube upload steps (v3)
1. Upload {NAME}_{VERSION}_EN.mp4 (video + English audio). YouTube plays only one audio stream per file and ignores embedded subtitles.
2. YouTube Studio -> Content -> the video -> Subtitles (or Languages):
   - Add language English -> Upload file -> subs_en.srt
   - Add language Russian -> Upload file -> subs_ru.srt
   - Add language Russian -> Audio -> upload Audio_RU.m4a (multi-language audio; needs an eligible channel).
3. If your channel has no multi-language audio: upload {NAME}_{VERSION}_RU.mp4 as a separate video.
4. Put the music credits below into the description.

{credits}
""", encoding="utf-8")
print("packaged")
