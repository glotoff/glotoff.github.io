"""Step 1: build inventory.json from all photos/videos using exiftool."""
import json, subprocess, sys
from pathlib import Path

ROOT = Path(__import__("os").environ.get("TRIP_ROOT", "."))
SRC = ROOT / "photos-and-videos"
OUT = ROOT / "build"
OUT.mkdir(exist_ok=True)
EXIFTOOL = __import__("os").environ.get("EXIFTOOL", "exiftool")

cmd = [EXIFTOOL, "-json", "-n", "-q", "-fast2",
       "-FileName", "-FileSize", "-DateTimeOriginal", "-CreateDate", "-MediaCreateDate",
       "-GPSLatitude", "-GPSLongitude", "-GPSAltitude", "-Model",
       "-ImageWidth", "-ImageHeight", "-Orientation", "-Duration", str(SRC)]
raw = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", check=True).stdout
rows = json.loads(raw)

items = []
for r in rows:
    name = r.get("FileName", "")
    ext = Path(name).suffix.lower()
    t = r.get("DateTimeOriginal") or r.get("CreateDate") or r.get("MediaCreateDate")
    items.append({
        "file": name,
        "kind": "video" if ext == ".mp4" else "photo",
        "screenshot": name.lower().startswith("screenshot"),
        "time": t,
        "lat": r.get("GPSLatitude"),
        "lon": r.get("GPSLongitude"),
        "camera": r.get("Model"),
        "w": r.get("ImageWidth"),
        "h": r.get("ImageHeight"),
        "orientation": r.get("Orientation"),
        "duration": r.get("Duration"),
        "size": r.get("FileSize"),
    })

(OUT / "inventory.json").write_text(json.dumps(items, indent=1), encoding="utf-8")

usable = [i for i in items if not i["screenshot"]]
gps = [i for i in usable if i["lat"] is not None]
print(f"total={len(items)} screenshots={len(items)-len(usable)} usable={len(usable)}")
print(f"photos={sum(i['kind']=='photo' for i in usable)} videos={sum(i['kind']=='video' for i in usable)}")
print(f"with GPS={len(gps)} ({100*len(gps)/max(1,len(usable)):.0f}%)")
from collections import Counter
print("cameras:", dict(Counter(i['camera'] for i in usable)))
