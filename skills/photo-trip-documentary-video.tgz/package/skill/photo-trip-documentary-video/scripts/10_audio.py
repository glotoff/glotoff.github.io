"""Step 10: mix narration + music (with ducking) per language -> build/audio_<lang>.m4a
Usage: python 10_audio.py [en|ru ...]"""
import json, subprocess, sys
from pathlib import Path

ROOT = Path(__import__("os").environ.get("TRIP_ROOT", "."))
BUILD = ROOT / "build"
MUSIC = ROOT / "music"
tl = json.loads((BUILD / "timeline.json").read_text(encoding="utf-8"))
total = tl["total"]
langs = sys.argv[1:] or ["en", "ru"]


def probe_dur(p):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)],
                       capture_output=True, text=True)
    return float(r.stdout.strip())


# integrated loudness (LUFS) of each track as downloaded; gain brings every track to about -19.5 LUFS before the mix
LUFS = {"Desert City.mp3": -12.4, "Eastern Thought.mp3": -19.9, "Ethereal Relaxation.mp3": -18.4, "Finding the Balance.mp3": -11.8,
        "Floating Cities.mp3": -19.8, "Journey To Ascend.mp3": -10.8, "Leaving Home.mp3": -13.8, "Mana Two - Part 2.mp3": -16.7,
        "Old Road.mp3": -16.4, "That Zen Moment.mp3": -18.6, "Touching Moments Two - Higher.mp3": -28.1}
def LUFS_GAIN(track):
    return -19.5 - LUFS[track]


tdur = {}
for lang in langs:
    inputs, chains = [], []
    k = 0
    mus_labels = []
    for mi, m in enumerate(tl["music"]):
        path = MUSIC / m["track"]
        td = tdur.setdefault(m["track"], probe_dur(path))
        off = m["offset"] % max(10.0, td - 5)
        length = m["end"] - m["start"] + (2.0 if mi < len(tl["music"]) - 1 else 0.0)
        inputs += ["-i", str(path)]
        loop_samples = int((td - off) * 44100)
        chains.append(
            f"[{k}:a]aresample=44100,aformat=channel_layouts=stereo,atrim=start={off:.2f},asetpts=PTS-STARTPTS,"
            f"aloop=loop=-1:size={loop_samples},atrim=duration={length:.2f},"
            f"afade=t=in:st=0:d=2,afade=t=out:st={max(0.1, length - 2.5):.2f}:d=2.5,"
            f"volume={LUFS_GAIN(m['track']):.2f}dB,adelay={int(m['start'] * 1000)}|{int(m['start'] * 1000)}[m{mi}]")
        mus_labels.append(f"[m{mi}]")
        k += 1
    chains.append("".join(mus_labels) + f"amix=inputs={len(mus_labels)}:normalize=0:duration=longest,volume=0.45[mus]")
    nar_labels = []
    for ni, n in enumerate(tl["narration"]):
        wav = BUILD / "audio" / lang / f"{n['uid']}.wav"
        if not wav.exists():
            print("missing narration:", lang, n["uid"])
            continue
        inputs += ["-i", str(wav)]
        ms = int(n["start"] * 1000)
        chains.append(f"[{k}:a]aresample=44100,pan=stereo|c0=c0|c1=c0,afade=t=in:d=0.03,adelay={ms}|{ms}[n{ni}]")
        nar_labels.append(f"[n{ni}]")
        k += 1
    chains.append("".join(nar_labels) + f"amix=inputs={len(nar_labels)}:normalize=0:duration=longest[nar]")
    chains.append("[nar]asplit=2[nar1][nar2]")
    chains.append("[mus][nar1]sidechaincompress=threshold=0.015:ratio=9:attack=20:release=500:makeup=1[duck]")
    chains.append(f"[duck][nar2]amix=inputs=2:normalize=0:duration=longest,apad,atrim=duration={total:.2f},"
                  f"loudnorm=I=-16:LRA=11:TP=-2,alimiter=limit=0.72:level=0[out]")
    out = BUILD / f"audio_{lang}.m4a"
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-hide_banner"] + inputs + [
        "-filter_complex", ";".join(chains), "-map", "[out]", "-c:a", "aac", "-b:a", "192k", "-ar", "44100", str(out)]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        print("FAIL", lang, r.stderr[-1500:])
    else:
        print("ok", lang, out, f"{probe_dur(out)/60:.1f} min")
