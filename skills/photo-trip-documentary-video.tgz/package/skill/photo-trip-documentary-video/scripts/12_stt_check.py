"""Detect narration clips that begin with the spoken style prompt. Uses Gemini transcription of the first 12 s."""
import json, io, wave, sys, time
from pathlib import Path
from google import genai
from google.genai import types
BUILD = (Path(__import__("os").environ.get("TRIP_ROOT", ".")) / "build")
tl = json.loads((BUILD/"timeline.json").read_text(encoding="utf-8"))
c = genai.Client()
res_p = BUILD/"stt_check.json"
res = json.loads(res_p.read_text(encoding="utf-8")) if res_p.exists() else {}
for n in tl["narration"]:
    for l in ("en","ru"):
        key=f"{l}/{n['uid']}"
        if key in res: continue
        w=wave.open(str(BUILD/"audio"/l/f"{n['uid']}.wav")); frames=w.readframes(24000*12)
        buf=io.BytesIO(); o=wave.open(buf,"wb"); o.setnchannels(1); o.setsampwidth(2); o.setframerate(24000); o.writeframes(frames); o.close()
        for att in range(4):
            try:
                r=c.models.generate_content(model="gemini-2.5-flash",contents=[
                  types.Part.from_bytes(data=buf.getvalue(),mime_type="audio/wav"),
                  "Transcribe this audio verbatim, nothing else."])
                res[key]=r.text.strip(); break
            except Exception as e:
                time.sleep(8*(att+1)); res[key]="ERR "+str(e)[:80]
        print(key, res[key][:90].replace("\n"," "), flush=True)
        res_p.write_text(json.dumps(res,ensure_ascii=False,indent=1),encoding="utf-8")
