"""Batch-API version of step 7: submit all missing clips as one batch job, poll, write wavs + audio_index.json.
Usage: python 07b_tts_batch.py [submit|collect]   (job name kept in build/batch_job.txt)"""
import json, sys, time, wave
from pathlib import Path
from google import genai
from tts_lib import clean_pcm

BUILD = (Path(__import__("os").environ.get("TRIP_ROOT", ".")) / "build")
MODEL = "gemini-3.8-flash-tts"
s = json.loads((BUILD / "script.json").read_text(encoding="utf-8"))
units = [("intro", s["intro"]["en"], s["intro"]["ru"]), ("outro", s["outro"]["en"], s["outro"]["ru"])]
for c in s["chapters"]:
    units.append((f"{c['id']}_intro", c["intro_en"], c["intro_ru"]))
    for i, g in enumerate(c["segments"], 1):
        units.append((f"{c['id']}_s{i:02d}", g["en"], g["ru"]))
idx_p = BUILD / "audio_index.json"
index = json.loads(idx_p.read_text(encoding="utf-8")) if idx_p.exists() else {}
todo = [(f"{l}/{u}", t) for u, en, ru in units for l, t in (("en", en), ("ru", ru)) if f"{l}/{u}" not in index]
cfg = {"response_modalities": ["AUDIO"], "speech_config": {"voice_config": {"prebuilt_voice_config": {"voice_name": "Charon"}}}}
c = genai.Client()
job_p = BUILD / "batch_job.txt"
mode = sys.argv[1] if len(sys.argv) > 1 else "submit"
if mode == "submit":
    reqs = [{"contents": [{"parts": [{"text": t}], "role": "user"}], "config": cfg} for _, t in todo]
    j = c.batches.create(model=MODEL, src=reqs, config={"display_name": "trip-tts"})
    job_p.write_text(j.name)
    (BUILD / "batch_keys.json").write_text(json.dumps([k for k, _ in todo]))
    print("submitted", j.name, len(reqs))
else:
    j = c.batches.get(name=job_p.read_text().strip())
    print(j.state)
    if j.state.name != "JOB_STATE_SUCCEEDED":
        sys.exit(2)
    keys = json.loads((BUILD / "batch_keys.json").read_text())
    ok = bad = 0
    for k, r in zip(keys, j.dest.inlined_responses):
        try:
            data = clean_pcm(r.response.candidates[0].content.parts[0].inline_data.data)
        except Exception as e:  # noqa
            bad += 1; print("BAD", k, str(r.error)[:100]); continue
        out = BUILD / "audio" / k.split("/")[0] / (k.split("/")[1] + ".wav")
        out.parent.mkdir(parents=True, exist_ok=True)
        with wave.open(str(out), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000); w.writeframes(data)
        index[k] = round(len(data) / 2 / 24000, 2); ok += 1
    idx_p.write_text(json.dumps(index, indent=1), encoding="utf-8")
    print("written", ok, "bad", bad)
