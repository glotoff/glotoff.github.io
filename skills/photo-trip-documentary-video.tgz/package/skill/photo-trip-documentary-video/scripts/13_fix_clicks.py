"""Silence the loud ~5 ms burst at the START of each raw TTS clip, then redo the 0.92 slowdown -> build/audio.
Durations are unchanged (burst is replaced by silence, not trimmed)."""
import json, subprocess, wave, glob
from pathlib import Path
import numpy as np
BUILD = (Path(__import__("os").environ.get("TRIP_ROOT", ".")) / "build")
tmp = BUILD / "audio_fixed_raw"
idx = json.loads((BUILD / "audio_index.json").read_text(encoding="utf-8"))
bad = 0
for k in idx:
    l, u = k.split("/")
    w = wave.open(str(BUILD / "audio_raw" / l / f"{u}.wav")); a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32); w.close()
    n = 48  # 2 ms windows
    for i in range(0, 1440, n):  # first 60 ms
        if np.sqrt((a[i:i + n] ** 2).mean()) / 32768 > 0.06:
            a[:i + n] = 0
    f = 480; start = int(np.argmax(np.abs(a) > 0)) if np.any(a[:2400] != 0) else 0
    a[start:start + f] *= np.linspace(0, 1, f)  # 20 ms fade-in
    out = tmp / l / f"{u}.wav"; out.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out), "wb") as o:
        o.setnchannels(1); o.setsampwidth(2); o.setframerate(24000); o.writeframes(a.astype(np.int16).tobytes())
    dst = BUILD / "audio" / l / f"{u}.wav"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(out), "-af", "atempo=0.92", "-ar", "24000", "-ac", "1", str(dst)], check=True)
    w = wave.open(str(dst)); d = round(w.getnframes() / w.getframerate(), 2); w.close()
    if abs(d - idx[k]) > 0.02: bad += 1; print("duration changed", k, idx[k], d)
print("done", len(idx), "duration mismatches", bad)
