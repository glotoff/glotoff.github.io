"""Step 6: narration script (EN + RU) -> build/script.json, with coverage check vs picks.txt.
Facts are limited to what web sources agreed on; uncertain numbers are phrased loosely."""
import json, re
from pathlib import Path

ROOT = Path(__import__("os").environ.get("TRIP_ROOT", "."))
BUILD = ROOT / "build"

TITLE = dict(en="Uzbekistan, October 2026", ru="Узбекистан, октябрь 2026",
             sub_en="From the Aral Sea to the Silk Road", sub_ru="От Аральского моря до Шёлкового пути")
INTRO = dict(
    en="Seven days in Uzbekistan. From the mountains above Tashkent, across the desert of Karakalpakstan, to the ancient walls of Khiva and back again. This is our journey.",
    ru="Семь дней в Узбекистане. От гор над Ташкентом через пустыни Каракалпакстана к древним стенам Хивы и обратно. Это наше путешествие.")
OUTRO = dict(
    en="Seven days, thousands of kilometres, and more history than we could ever fit into one film. Thank you for travelling with us.",
    ru="Семь дней, тысячи километров и больше истории, чем можно уместить в один фильм. Спасибо, что были с нами.")

# chapter: id, title en/ru, day en/ru, intro en/ru, segments
# segment: labels, place_en, place_ru, en, ru
CH = []

def ch(id, ten, tru, den, dru, ien, iru, segs):
    CH.append(dict(id=id, title_en=ten, title_ru=tru, day_en=den, day_ru=dru, intro_en=ien, intro_ru=iru, segments=segs))

def seg(labels, pen, pru, en, ru):
    return dict(labels=labels.split(), place_en=pen, place_ru=pru, en=en, ru=ru)

ch("C1", "Chimgan Mountains", "Горы Чимган", "Day 1 · October 11", "День 1 · 11 октября",
   "We begin in the mountains outside Tashkent, where the air is cool and the autumn light is soft.",
   "Мы начинаем в горах за Ташкентом, где прохладный воздух и мягкий осенний свет.",
   [seg("0.1V 1.1 1.4", "Chimgan", "Чимган",
        "Morning in the hills. From the hotel window we watch riders on horseback cross the slope, and the first breakfast of the trip comes with a view.",
        "Утро в горах. Из окна отеля мы смотрим, как по склону едут всадники, и первый завтрак в этой поездке подан с видом."),
    seg("2.1 2.3 2.5 3.2 3.3", "Chimgan", "Чимган",
        "A dirt track leads up towards the peaks. Clouds drift over the western Tian Shan, and the hotel sits on its ridge like a small mountain village.",
        "Грунтовая дорога ведёт к вершинам. Над западным Тянь-Шанем плывут облака, а отель на гребне похож на маленькую горную деревню."),
    seg("4.3", "Tashkent", "Ташкент",
        "Lunch in the shade of pine trees, and a first taste of Uzbek hospitality.",
        "Обед в тени сосен и первое знакомство с узбекским гостеприимством.")])

ch("C2", "Mizdakhan and Gyaur-Kala", "Миздахкан и Гяур-Кала", "Day 2 · October 12", "День 2 · 12 октября",
   "The next morning we fly west, to Karakalpakstan, a vast autonomous republic on the edge of the Aral Sea.",
   "Утром мы летим на запад, в Каракалпакстан, огромную автономную республику на краю Аральского моря.",
   [seg("10.3", "Nukus", "Нукус",
        "Day two begins in Nukus, the capital of Karakalpakstan, seen from our hotel window.",
        "Второй день начинается в Нукусе, столице Каракалпакстана, вид из окна нашего отеля."),
    seg("12.3 13.1 13.6 13.9 13.14", "Mizdakhan", "Миздахкан",
        "Mizdakhan, near the town of Khujayli, is one of the oldest burial grounds in Central Asia. Sources date its beginnings to around the fourth century BC. Here, domes rise out of the dust and a doorway opens onto turquoise tile.",
        "Миздахкан близ города Ходжейли — один из древнейших некрополей Центральной Азии. Его начало относят примерно к IV веку до нашей эры. Здесь из пыли поднимаются купола, а за дверью открывается бирюзовая плитка."),
    seg("13.16 13.18 13.20 13.29 13.30 13.35 13.39", "Mizdakhan", "Миздахкан",
        "Local tradition holds that the grave of Adam lies here, and for centuries pilgrims have come. Brick mausoleums, carved wooden doors and an ocean of old graves stretch over the hills.",
        "По местному преданию, здесь находится могила Адама, и веками сюда приходили паломники. Кирпичные мавзолеи, резные деревянные двери и море старых могил раскинулись по холмам."),
    seg("14.2 14.9 14.16 14.25 14.32", "Gyaur-Kala", "Гяур-Кала",
        "Nearby stands Gyaur-Kala, a fortress whose name is often translated as the fortress of the unbelievers. Its walls, eroded by wind and time, were home to a Zoroastrian community before the Arab conquest.",
        "Рядом стоит Гяур-Кала, крепость, чьё имя часто переводят как крепость неверных. Её стены, источенные ветром и временем, принадлежали зороастрийской общине до арабского завоевания."),
    seg("14.35 14.43 14.46 14.52 14.55", "Gyaur-Kala", "Гяур-Кала",
        "Climbing among the ruins, you start to understand the scale. Towers stand alone on the mounds, and beyond them the green valley and the modern town.",
        "Поднимаясь среди руин, начинаешь понимать масштаб. Башни стоят одиноко на холмах, а за ними — зелёная долина и современный город.")])

ch("C3", "Moynaq: the Ship Graveyard", "Мойнак: кладбище кораблей", "Day 2 · October 12", "День 2 · 12 октября",
   "Then the road north, towards what used to be the sea.",
   "Затем дорога на север, туда, где когда-то было море.",
   [seg("16.1 17.9 10.7V 11.4V 11.5V 11.6V", "Moynaq", "Мойнак",
        "The road crosses a dry salt bed. Moynaq was once a fishing port on the Aral Sea. Soviet-era irrigation drained the rivers that fed the sea, and the shoreline retreated many kilometres into the desert.",
        "Дорога пересекает сухое солончаковое дно. Мойнак был рыбацким портом на Аральском море. Советское орошение отняло воду у питавших море рек, и берег отступил на многие километры вглубь пустыни."),
    seg("18.2 18.12 18.15 18.19 18.22", "Moynaq", "Мойнак",
        "And there they are. Fishing boats, left behind when the water went, rust in the sand under a cloudless sky.",
        "И вот они. Рыбацкие суда, оставленные, когда ушла вода, ржавеют в песке под безоблачным небом."),
    seg("18.25 18.32 18.34 18.37 18.40", "Moynaq", "Мойнак",
        "Fishing here stopped in the late nineteen-eighties. Today the ships are an open-air museum, covered in graffiti and silence.",
        "Рыбная ловля здесь прекратилась в конце восьмидесятых. Сегодня корабли — музей под открытым небом, покрытый граффити и тишиной."),
    seg("18.46 18.52 18.56 18.60 18.66", "Moynaq", "Мойнак",
        "Some hulls are almost intact; others are only ribs. A rusted crane stands among the dunes where the harbour once was.",
        "Одни корпуса почти целы, от других остались лишь рёбра. Ржавый кран стоит среди дюн там, где когда-то была гавань."),
    seg("19.1 19.9 19.10 19.14 19.22 19.28 19.31", "Moynaq", "Мойнак",
        "From the viewpoint you see how far the wrecks are scattered. A signpost points to cities across the world, and the horizon is where the water used to be.",
        "С обзорной площадки видно, как далеко разбросаны остовы. Указатель показывает города по всему миру, а горизонт — там, где раньше была вода.")])

ch("C4", "Nukus and Chilpik Dakhma", "Нукус и Чилпык-дахма", "Day 2–3 · October 12–13", "День 2–3 · 12–13 октября",
   "Back in Nukus, evening falls, and the next morning belongs to art, and to the desert.",
   "Вечером мы возвращаемся в Нукус, а следующее утро принадлежит искусству и пустыне.",
   [seg("20.3", "Nukus", "Нукус",
        "A Soviet-era mosaic glows on a wall in the night.",
        "Советская мозаика светится на стене в ночи."),
    seg("24.7 24.14 24.20 24.23 24.31", "Savitsky Museum, Nukus", "Музей Савицкого, Нукус",
        "In a remote desert town stands one of the great surprises of Central Asia: the Savitsky Museum. Igor Savitsky gathered works that Soviet authorities had suppressed, and today it holds one of the largest collections of Russian avant-garde art in the world.",
        "В далёком пустынном городе находится одна из главных неожиданностей Центральной Азии — музей Савицкого. Игорь Савицкий собрал произведения, которые советская власть не терпела, и сегодня это одна из крупнейших в мире коллекций русского авангарда."),
    seg("24.36 24.34 24.45 24.48", "Nukus", "Нукус",
        "On the streets of Nukus, apartment blocks wear ornament like carpets, autumn leaves turn gold, and a yurt stands in a museum hall.",
        "На улицах Нукуса многоэтажки украшены орнаментом, как ковры, осенние листья желтеют, а в зале музея стоит юрта."),
    seg("23.3V 25.7 26.1 26.5", "Chilpik Dakhma", "Чилпык-дахма",
        "South of Nukus, a concrete stairway climbs through the desert towards Chilpik Dakhma, an ancient Zoroastrian Tower of Silence.",
        "К югу от Нукуса бетонная лестница поднимается через пустыню к Чилпык-дахме, древней зороастрийской Башне молчания."),
    seg("27.1 27.5 27.9 27.11 27.13 27.22", "Chilpik Dakhma", "Чилпык-дахма",
        "A circular adobe structure, roughly two thousand years old by most estimates. Here the dead were laid out for the birds, in keeping with Zoroastrian belief. From the top, the Amu Darya valley spreads below.",
        "Круглое глинобитное сооружение, которому, по большинству оценок, около двух тысяч лет. Здесь тела оставляли птицам, согласно зороастрийскому обычаю. С вершины внизу раскинулась долина Амударьи."),
    seg("28.3 29.1 29.3", "Amu Darya", "Амударья",
        "We cross the Amu Darya, the great river of Central Asia, and end the day in a camp where even the bedroom ceiling is a painted dome.",
        "Мы пересекаем Амударью, великую реку Центральной Азии, и заканчиваем день в лагере, где даже потолок спальни — расписной купол.")])

ch("C5", "Khiva: the Walled City", "Хива: город за стенами", "Day 4 · October 14", "День 4 · 14 октября",
   "On the fourth day we reach Khiva, a city that seems to have stepped out of a storybook.",
   "На четвёртый день мы добираемся до Хивы, города, словно сошедшего со страниц сказки.",
   [seg("32.1 32.5", "Amu Darya", "Амударья",
        "Morning by the river. Reflections hold perfectly still.",
        "Утро у реки. Отражения совершенно неподвижны."),
    seg("32.12V 33.1V 33.2V 34.1", "Khiva", "Хива",
        "Then through the gate and into Ichan-Kala, the old walled town. Inside, the lanes fill with bazaar stalls, and even our guesthouse room is domed and painted.",
        "Затем через ворота — в Ичан-Калу, старый город за стенами. Внутри переулки заполнены рядами базара, а даже комната в нашем гостевом доме — под расписным куполом."),
    seg("35.1 35.2 35.12 35.18 35.23", "Ichan-Kala, Khiva", "Ичан-Кала, Хива",
        "Ichan-Kala was inscribed on the UNESCO World Heritage list in 1990. Minarets, domes and madrasas cluster inside walls of mud brick.",
        "Ичан-Кала внесена в список Всемирного наследия ЮНЕСКО в 1990 году. Минареты, купола и медресе теснятся внутри глиняных стен."),
    seg("35.26 35.29 35.49 35.53 35.58 35.56", "Ichan-Kala, Khiva", "Ичан-Кала, Хива",
        "The Islam Khoja minaret, among the tallest in the city, rises in banded tile. Portals open onto courtyards, and each madrasa seems more elaborate than the last.",
        "Минарет Ислам-Ходжа, один из самых высоких в городе, поднимается полосами изразцов. Порталы открываются во дворы, и каждое медресе кажется богаче предыдущего."),
    seg("35.39 35.42 35.45 35.69", "Juma Mosque, Khiva", "Джума-мечеть, Хива",
        "Inside the Juma Mosque there is no grand dome, only a forest of carved wooden columns, more than a hundred of them, each different, some of them centuries old.",
        "В мечети Джума нет большого купола — только лес резных деревянных колонн, их больше сотни, и каждая не похожа на другую, некоторые стоят веками."),
    seg("35.65 35.76 35.82 35.70 35.85 36.3 36.9 36.18", "Tash Hauli Palace, Khiva", "Дворец Таш-Хаули, Хива",
        "Tash Hauli, the khan's palace, was built in the nineteenth century. Courtyards are walled in blue and white tile, and every doorway and ceiling is painted by hand.",
        "Таш-Хаули, дворец хана, построен в XIX веке. Дворы облицованы сине-белой плиткой, а каждая дверь и каждый потолок расписаны вручную."),
    seg("36.31 36.35 36.40 36.45 36.47 36.50", "Ichan-Kala, Khiva", "Ичан-Кала, Хива",
        "We wander the lanes at an easy pace. A gate flanked by turquoise domes, a minaret slipping behind a wall, and a pause under an arch.",
        "Мы неспешно бродим по переулкам. Ворота с бирюзовыми куполами, минарет, ускользающий за стену, и короткая остановка под аркой."),
    seg("36.56 36.65", "Khiva", "Хива",
        "As the sun lowers, the walls turn gold.",
        "Когда солнце клонится к закату, стены становятся золотыми."),
    seg("37.3 37.7 37.9 37.17", "Khiva", "Хива",
        "Kalta Minor, the unfinished minaret, glows against the dusk. Construction was reportedly halted in the 1850s, and it was never raised to its planned height.",
        "Кальта-Минор, незавершённый минарет, светится на фоне сумерек. Строительство, как говорят, остановилось в 1850-х, и он так и не достиг задуманной высоты."),
    seg("37.27 37.38 37.43 37.48", "Khiva", "Хива",
        "From a rooftop terrace we watch Khiva turn blue, then gold, as the minarets light up one by one.",
        "С крыши мы смотрим, как Хива становится синей, потом золотой, а минареты зажигаются один за другим."),
    seg("37.51 37.55 37.62 37.66 37.76 35.92V 35.94V 35.98V 35.99V", "Khiva by night", "Хива ночью",
        "At night the old town is almost empty. Floodlit walls, quiet alleys and a courtyard dinner under arches. A day to remember.",
        "Ночью старый город почти пуст. Подсвеченные стены, тихие переулки и ужин во дворе под арками. День, который запомнится.")])

ch("C6", "Khiva: Walls, Palaces and Dusk", "Хива: стены, дворцы и закат", "Day 5 · October 15", "День 5 · 15 октября",
   "We rise early, because Khiva is best before the crowds arrive.",
   "Мы встаём рано, потому что Хива лучше всего до прихода толпы.",
   [seg("38.1V 39.1 39.4 39.11 39.15", "Khiva", "Хива",
        "Dawn over the rooftops. Domes and minarets slowly emerge from the haze.",
        "Рассвет над крышами. Купола и минареты медленно появляются из дымки."),
    seg("39.27 39.32 39.36 39.39 39.47 39.52 39.62 39.69", "Khiva", "Хива",
        "In the early light the lanes are ours. Sun slants down narrow streets, a madrasa courtyard sits in silence, and a tower guards a corner.",
        "В ранних лучах переулки принадлежат нам. Солнце косо падает на узкие улицы, двор медресе безмолвен, а башня охраняет угол."),
    seg("40.2 40.15 40.34 40.39 40.47", "City Walls, Khiva", "Городские стены, Хива",
        "Then up onto the city walls. You can walk along the top of the ramparts, with battlements on one side and the entire town spread out on the other.",
        "Затем мы поднимаемся на городские стены. По ним можно пройти, с одной стороны зубцы, с другой — весь город как на ладони."),
    seg("40.64 40.67 40.77 40.89 41.5 41.7", "Khiva", "Хива",
        "Kalta Minor again, now in full sun, its tiles glittering. Behind the garden, a street runs straight to a minaret.",
        "Кальта-Минор снова, теперь при полном солнце, его изразцы сверкают. За садом улица ведёт прямо к минарету."),
    seg("41.10 41.11 41.16 41.23 41.31 41.38 41.49 41.53", "Khiva", "Хива",
        "The mausoleum of Pahlavan Mahmud, with its green dome, sits beside the Islam Khoja minaret. Courtyards, tall brick towers and a stone-paved alley between walls.",
        "Мавзолей Пахлавана Махмуда с зелёным куполом стоит рядом с минаретом Ислам-Ходжа. Дворы, высокие кирпичные башни и мощёный камнем проход между стенами."),
    seg("41.63 41.64 41.67", "Khiva", "Хива",
        "And a camel, apparently unbothered by tourists, by the wall.",
        "И верблюд, совершенно равнодушный к туристам, у стены."),
    seg("42.3 42.9 42.21 42.22", "Kunya-Ark, Khiva", "Куня-Арк, Хива",
        "Kunya-Ark, the khans' old citadel, dates from the seventeenth century. Its reception court, with painted wooden columns and a throne, is where rulers once met their guests.",
        "Куня-Арк, древняя цитадель ханов, относится к XVII веку. В её приёмном дворе, с расписными деревянными колоннами и троном, правители встречали гостей."),
    seg("42.35 42.38 42.41", "Khiva", "Хива",
        "Our last evening in Khiva. Pink clouds above the minarets, and the Silk Road feels very close.",
        "Наш последний вечер в Хиве. Розовые облака над минаретами, и Шёлковый путь кажется совсем близко.")])

ch("C7", "Fortresses of Ancient Khorezm", "Крепости древнего Хорезма", "Day 6 · October 16", "День 6 · 16 октября",
   "On the sixth day we leave the city for the desert, to the fortresses of ancient Khorezm.",
   "На шестой день мы покидаем город ради пустыни, ради крепостей древнего Хорезма.",
   [seg("43.2V 46.4 47.2 47.8 47.11", "Ayaz-Kala", "Аязкала",
        "Ayaz-Kala, among the largest of the desert fortresses. It was part of a chain of fortifications guarding the Khorezm oasis, and was explored by Soviet archaeologists in the twentieth century.",
        "Аязкала — одна из крупнейших пустынных крепостей. Она входила в цепь укреплений, охранявших Хорезмский оазис, и была исследована советскими археологами в XX веке."),
    seg("47.17 47.22 47.34 47.52 47.57 47.64", "Ayaz-Kala", "Аязкала",
        "From the top, the Kyzylkum desert runs to every horizon, and the fortress below looks like a ship on a sea of sand.",
        "С вершины пустыня Кызылкум уходит к горизонту во все стороны, а крепость внизу похожа на корабль в море песка."),
    seg("48.4 48.13 48.17 48.19 48.25 48.34 49.5 49.8", "Toprak-Kala", "Тупрак-кала",
        "Toprak-Kala was a royal residence and administrative centre in the first centuries of our era. Today it is a maze of rooms and halls, open to the sky.",
        "Тупрак-кала была царской резиденцией и административным центром в первые века нашей эры. Сегодня это лабиринт комнат и залов под открытым небом."),
    seg("50.3 50.6 50.8 50.23 50.29 50.35 50.39", "Kyzyl-Kala", "Кызыл-кала",
        "Kyzyl-Kala, the Red Fortress, named for the colour of its mud-brick walls. Steep stairs climb inside, and the walls rise in tapering, angled bastions.",
        "Кызыл-кала, Красная крепость, названа по цвету глинобитных стен. Внутри круто поднимаются ступени, а стены вздымаются суживающимися угловатыми бастионами."),
    seg("51.3", "Urgench", "Ургенч",
        "In Urgench, a monument to the Avesta, the sacred book of Zoroastrianism, reminds us that this land may be one of its cradles.",
        "В Ургенче памятник Авесте, священной книге зороастризма, напоминает, что эта земля, возможно, одна из его колыбелей.")])

ch("C8", "Tashkent", "Ташкент", "Day 7 · October 17", "День 7 · 17 октября",
   "Our final day brings us back to Tashkent, Uzbekistan's modern capital.",
   "Последний день возвращает нас в Ташкент, современную столицу Узбекистана.",
   [seg("54.1V 56.1 56.6 56.11 56.16 56.29", "Hazrat Imam Complex, Tashkent", "Комплекс Хазрати Имам, Ташкент",
        "The Hazrat Imam complex grew around the tomb of an early imam of Tashkent, Abu Bakr Kaffal Shashi. Wooden columns hold up the courtyard roofs, and the great mosque has a dome of blue and gold.",
        "Комплекс Хазрати Имам вырос вокруг гробницы раннего имама Ташкента Абу Бакра Каффаля Шаши. Деревянные колонны поддерживают крыши двора, а в большой мечети — сине-золотой купол."),
    seg("56.32 56.33 56.35 56.40 56.43 57.3", "Hazrat Imam Complex, Tashkent", "Комплекс Хазрати Имам, Ташкент",
        "The Barak Khan Madrasa, from the sixteenth century, is now a craft centre. Nearby, the state history museum shows stone figures from the distant past.",
        "Медресе Барак-хана, XVI века, сегодня — центр ремёсел. Неподалёку государственный музей истории показывает каменные фигуры далёкого прошлого."),
    seg("55.2V 58.6 58.11 58.14 58.17 58.5", "Besh Qozon, Tashkent", "Беш-Козон, Ташкент",
        "We finish the way every Uzbek journey should end: with plov. At the Central Asian Pilaf Centre it is cooked in enormous cauldrons over open fire.",
        "Мы заканчиваем так, как должно заканчиваться любое путешествие по Узбекистану: пловом. В Центре плова его готовят в огромных казанах на открытом огне.")])

script = dict(title=TITLE, intro=INTRO, outro=OUTRO, chapters=CH)
(BUILD / "script.json").write_text(json.dumps(script, indent=1, ensure_ascii=False), encoding="utf-8")

# coverage check against picks
def norm(l): return l.replace("V", " VID") if l.endswith("V") else l
want = []
for line in (BUILD / "picks.txt").read_text(encoding="utf-8").splitlines():
    if line.strip() and not line.startswith("#"):
        lab = line.split("|")[0].strip()
        want.append(lab.replace(" VID", "V"))
used = [l for c in CH for s in c["segments"] for l in s["labels"]]
dup = sorted({l for l in used if used.count(l) > 1})
missing = sorted(set(want) - set(used))
extra = sorted(set(used) - set(want))
words_en = sum(len(s["en"].split()) for c in CH for s in c["segments"]) + sum(len(c["intro_en"].split()) for c in CH) + len(INTRO["en"].split()) + len(OUTRO["en"].split())
words_ru = sum(len(s["ru"].split()) for c in CH for s in c["segments"]) + sum(len(c["intro_ru"].split()) for c in CH)
print(f"segments={sum(len(c['segments']) for c in CH)} used={len(used)} want={len(want)}")
print("missing:", missing, "| extra:", extra, "| duplicates:", dup)
print(f"EN words ~{words_en} (~{words_en/150:.1f} min at 150 wpm); RU words ~{words_ru}")
