"""Step 5: turn build/picks.txt into build/storyboard.json (chapters -> ordered items)."""
import json, re
from pathlib import Path

ROOT = Path(__import__("os").environ.get("TRIP_ROOT", "."))
BUILD = ROOT / "build"

manifest = json.loads((BUILD / "sheet_manifest.json").read_text(encoding="utf-8"))
inv = {i["file"]: i for i in json.loads((BUILD / "inventory.json").read_text(encoding="utf-8"))}
stops = {s["id"]: s for s in json.loads((BUILD / "stops.json").read_text(encoding="utf-8"))}

CHAPTERS = [
    ("C1", "Chimgan Mountains", "2026-10-11", range(0, 8)),
    ("C2", "Mizdakhan and Gyaur-Kala", "2026-10-12", range(8, 15)),
    ("C3", "Moynaq: the Ship Graveyard", "2026-10-12", range(15, 20)),
    ("C4", "Nukus and Chilpik Dakhma", "2026-10-12/13", range(20, 30)),
    ("C5", "Khiva: the Walled City", "2026-10-14", range(30, 38)),
    ("C6", "Khiva: Walls, Palaces and Dusk", "2026-10-15", range(38, 43)),
    ("C7", "Fortresses of Ancient Khorezm", "2026-10-16", range(43, 53)),
    ("C8", "Tashkent", "2026-10-17", range(54, 59)),
]

def chapter_of(stop):
    for cid, title, day, rng in CHAPTERS:
        if stop in rng:
            return cid
    return None

picks = []
missing = []
for line in (BUILD / "picks.txt").read_text(encoding="utf-8").splitlines():
    if not line.strip() or line.startswith("#"):
        continue
    label, _, note = [p.strip() for p in line.partition("|")]
    m = manifest.get(label)
    if not m:
        missing.append(label)
        continue
    stop = m["stop"]
    idx = int(re.match(r"\d+\.(\d+)", label).group(1))
    i = inv[m["file"]]
    picks.append(dict(label=label, file=m["file"], kind="video" if m["kind"] == "V" else "photo", note=note, stop=stop, idx=idx,
                      time=m["t"], w=i["w"], h=i["h"], duration=i["duration"], camera=i["camera"],
                      center=stops[stop]["center"], place=stops[stop]["place"]))

picks.sort(key=lambda p: (p["stop"], p["idx"]))
out = []
for cid, title, day, rng in CHAPTERS:
    items = [p for p in picks if chapter_of(p["stop"]) == cid]
    out.append(dict(id=cid, title=title, day=day, items=items))

(BUILD / "storyboard.json").write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
tot_p = sum(1 for p in picks if p["kind"] == "photo")
tot_v = sum(1 for p in picks if p["kind"] == "video")
vsec = sum(min(p["duration"] or 8, 8) for p in picks if p["kind"] == "video")
print(f"picks={len(picks)} photos={tot_p} clips={tot_v} missing={missing}")
for c in out:
    n = len(c["items"])
    print(f"{c['id']} {c['title']:<36} {c['day']:<14} items={n:3d}  ~{n*7.5/60:.1f} min")
est = (tot_p * 7.5 + vsec) / 60
print(f"estimated runtime ~{est:.1f} min (photos 7.5s, clips up to 8s; excludes titles)")
