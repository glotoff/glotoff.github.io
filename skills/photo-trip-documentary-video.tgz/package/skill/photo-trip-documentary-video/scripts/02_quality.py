"""Step 2: sharpness / exposure scoring and near-duplicate grouping -> build/quality.json"""
import json, sys
from datetime import datetime
from multiprocessing import Pool
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps
import imagehash

ROOT = Path(__import__("os").environ.get("TRIP_ROOT", "."))
SRC = ROOT / "photos-and-videos"
BUILD = ROOT / "build"
THUMBS = BUILD / "thumbs"
THUMBS.mkdir(parents=True, exist_ok=True)


def score(name):
    try:
        im = Image.open(SRC / name)
        im.draft("RGB", (1000, 1000))
        im = ImageOps.exif_transpose(im).convert("RGB")
        im.thumbnail((900, 900))
        im.save(THUMBS / (Path(name).stem + ".jpg"), quality=82)
        g = np.asarray(im.convert("L"), dtype=np.float32)
        lap = (-4 * g[1:-1, 1:-1] + g[:-2, 1:-1] + g[2:, 1:-1] + g[1:-1, :-2] + g[1:-1, 2:])
        sharp = float(lap.var())
        mean = float(g.mean())
        clip_dark = float((g < 12).mean())
        clip_bright = float((g > 245).mean())
        ph = str(imagehash.phash(im))
        return name, dict(sharp=sharp, mean=mean, dark=clip_dark, bright=clip_bright, phash=ph,
                          w=im.width, h=im.height)
    except Exception as e:  # noqa
        return name, dict(error=str(e))


def parse_t(t):
    try:
        return datetime.strptime(t[:19], "%Y:%m:%d %H:%M:%S")
    except Exception:
        return None


if __name__ == "__main__":
    inv = json.loads((BUILD / "inventory.json").read_text(encoding="utf-8"))
    photos = [i for i in inv if i["kind"] == "photo" and not i["screenshot"]]
    with Pool(6) as p:
        res = dict(p.imap_unordered(score, [i["file"] for i in photos], chunksize=8))

    rows = []
    for i in photos:
        r = res[i["file"]]
        if "error" in r:
            print("ERR", i["file"], r["error"]); continue
        r["file"] = i["file"]; r["time"] = i["time"]
        r["t"] = parse_t(i["time"]) if i["time"] else None
        # quality: sharpness (log-scaled), penalise bad exposure
        q = np.log1p(r["sharp"])
        if r["mean"] < 40 or r["mean"] > 215: q -= 1.0
        q -= 6 * max(0, r["dark"] - 0.25) + 6 * max(0, r["bright"] - 0.15)
        r["q"] = float(q)
        rows.append(r)

    rows.sort(key=lambda r: (r["t"] is None, r["t"], r["file"]))
    # group near-duplicates: consecutive shots within 45s and similar phash
    gid = -1; prev = None
    for r in rows:
        same = False
        if prev is not None and r["t"] and prev["t"]:
            dt = (r["t"] - prev["t"]).total_seconds()
            d = imagehash.hex_to_hash(r["phash"]) - imagehash.hex_to_hash(prev["phash"])
            same = dt <= 45 and d <= 14
        if not same:
            gid += 1
        r["group"] = gid
        prev = r

    best = {}
    for r in rows:
        if r["group"] not in best or r["q"] > best[r["group"]]["q"]:
            best[r["group"]] = r
    for r in rows:
        r["keep"] = best[r["group"]]["file"] == r["file"]
        r["t"] = r["t"].isoformat() if r["t"] else None
        r["blurry"] = bool(r["q"] < np.percentile([x["q"] for x in rows], 8))

    (BUILD / "quality.json").write_text(json.dumps(rows, indent=1), encoding="utf-8")
    keep = [r for r in rows if r["keep"]]
    ok = [r for r in keep if not r["blurry"]]
    print(f"photos scored={len(rows)} groups={gid+1} kept-after-dedupe={len(keep)} kept-and-sharp={len(ok)}")
